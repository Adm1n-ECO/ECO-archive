-- ============================================================
-- EternalCurrent.Online — Add Languages Spoken
-- File: 12_ADD_LANGUAGES.sql
-- Generated: 2026-04-05
--
-- Adds languages_spoken as a text array to users.
-- A member can speak multiple languages — TEXT[] is the
-- correct Postgres type for this.
-- Updates users_public view to expose the field.
-- ============================================================

-- Step 1: Add column
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS languages_spoken TEXT[];

COMMENT ON COLUMN users.languages_spoken IS
  'Languages spoken by this member. Array of plain text values
   e.g. {English, Hindi, Punjabi, Fijian Hindi}.
   Populated via profile claim flow or admin update.';

-- Step 2: Recreate users_public view with new column
-- (Must drop first — Postgres cannot add columns to views in place)
DROP VIEW IF EXISTS users_public;

CREATE VIEW users_public AS
SELECT
  user_id, network_id, full_name, first_name, middle_name,
  last_name, nickname, platform_role, family_role, status, tier,
  gender, cultural_origin, birth_mm_yyyy, birth_location,
  current_location, household_id, parent_id, co_parent_id,
  partner_id, partner_type, social_links, photo_id,
  invite_status, visible_to, bio,
  birth_lat, birth_lon, current_lat, current_lon,
  languages_spoken,
  created_at, updated_at
FROM users;

COMMENT ON VIEW users_public IS
  'Safe read view for frontend. Email and auth_id structurally excluded.';

-- Re-grant permissions
GRANT SELECT ON users_public TO anon;
GRANT SELECT ON users_public TO authenticated;

-- Step 3: Seed known languages for existing members
-- Based on cultural origin and family knowledge.
-- Members will expand/correct their own via profile claim flow.

-- Bakshi family (India/Pakistan origin) — Hindi + English base
UPDATE users SET languages_spoken = ARRAY['English','Hindi']
WHERE cultural_origin = 'India'
  AND languages_spoken IS NULL;

-- Pakistan origin — Urdu + English base
UPDATE users SET languages_spoken = ARRAY['English','Urdu']
WHERE cultural_origin = 'Pakistan'
  AND languages_spoken IS NULL;

-- Fiji origin — Fijian Hindi + English base
UPDATE users SET languages_spoken = ARRAY['English','Fijian Hindi']
WHERE cultural_origin = 'Fiji'
  AND languages_spoken IS NULL;

-- STAR (Vikas) specifically — Hindi, Punjabi, English
UPDATE users SET languages_spoken = ARRAY['English','Hindi','Punjabi']
WHERE user_id = 'STAR';

-- Reema (Fiji origin) — Fijian Hindi, English, Hindi
UPDATE users SET languages_spoken = ARRAY['English','Fijian Hindi','Hindi']
WHERE user_id = 'RRB-STAR';

-- Isaiah (Adopted, US born) — English primary
UPDATE users SET languages_spoken = ARRAY['English']
WHERE user_id = 'IB-STAR';

-- Step 4: Verify — languages distribution
SELECT
  unnest(languages_spoken) AS language,
  COUNT(*) AS speakers
FROM users
WHERE languages_spoken IS NOT NULL
GROUP BY language
ORDER BY speakers DESC;
