-- ============================================================
-- EternalCurrent.Online — Language Updates
-- File: 13_LANGUAGE_UPDATES.sql
-- Generated: 2026-04-05
--
-- Updates:
-- 1. All Patels   → add Gujarati
-- 2. Vikas (STAR) → add Spanish
-- 3. All Fiji-born AND all Singhs → add Fijian Hindi + Hindi
--
-- Uses array deduplication so running this twice is safe.
-- Pattern: unnest existing + new → DISTINCT → rebuild array
-- ============================================================


-- ============================================================
-- HELPER: safe array merge without duplicates
-- Syntax: ARRAY(SELECT DISTINCT unnest(existing || new_values))
-- ============================================================


-- ============================================================
-- 1. ALL PATELS — add Gujarati
-- ============================================================

UPDATE users
SET    languages_spoken = ARRAY(
         SELECT DISTINCT unnest(
           COALESCE(languages_spoken, ARRAY[]::TEXT[]) || ARRAY['Gujarati']
         ) ORDER BY 1
       ),
       updated_at = NOW()
WHERE  last_name = 'Patel';


-- ============================================================
-- 2. VIKAS BAKSHI (STAR) — add Spanish
-- ============================================================

UPDATE users
SET    languages_spoken = ARRAY(
         SELECT DISTINCT unnest(
           COALESCE(languages_spoken, ARRAY[]::TEXT[]) || ARRAY['Spanish']
         ) ORDER BY 1
       ),
       updated_at = NOW()
WHERE  user_id = 'STAR';


-- ============================================================
-- 3a. ALL FIJI-BORN — add Fijian Hindi + Hindi
-- (Some already have Fijian Hindi from seed — dedup handles it)
-- ============================================================

UPDATE users
SET    languages_spoken = ARRAY(
         SELECT DISTINCT unnest(
           COALESCE(languages_spoken, ARRAY[]::TEXT[]) || ARRAY['Fijian Hindi','Hindi']
         ) ORDER BY 1
       ),
       updated_at = NOW()
WHERE  birth_location ILIKE '%Fiji%';


-- ============================================================
-- 3b. ALL SINGHS — add Fijian Hindi + Hindi
-- Singh family roots are in Fiji regardless of birth location
-- ============================================================

UPDATE users
SET    languages_spoken = ARRAY(
         SELECT DISTINCT unnest(
           COALESCE(languages_spoken, ARRAY[]::TEXT[]) || ARRAY['Fijian Hindi','Hindi']
         ) ORDER BY 1
       ),
       updated_at = NOW()
WHERE  last_name = 'Singh';


-- ============================================================
-- VERIFICATION
-- ============================================================

-- Show all members with their languages
SELECT
  full_name,
  last_name,
  birth_location,
  languages_spoken
FROM users
WHERE languages_spoken IS NOT NULL
ORDER BY last_name, first_name;

-- Network-wide language distribution
SELECT
  unnest(languages_spoken) AS language,
  COUNT(*)                  AS speakers
FROM users
WHERE languages_spoken IS NOT NULL
GROUP BY language
ORDER BY speakers DESC;
