-- ============================================================
-- EternalCurrent.Online — Geocoded Coordinates
-- File: 11_GEOCODE_LOCATIONS.sql
-- Generated: 2026-04-04
--
-- 25 unique location strings geocoded from People_Master
-- and Journeys_Media. Coordinates are accurate to city center.
-- Country-only entries (Pakistan) use geographic center.
--
-- STEP 1: Add lat/lon columns to users table
-- STEP 2: Create locations lookup table
-- STEP 3: Populate users lat/lon from lookup
-- STEP 4: Create geocode function for on-save triggers
-- ============================================================


-- ============================================================
-- STEP 1: Add coordinate columns to users table
-- birth_lat/lon and current_lat/lon stored separately
-- so globe can draw arcs between origin and present
-- ============================================================

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS birth_lat     NUMERIC(9,5),
  ADD COLUMN IF NOT EXISTS birth_lon     NUMERIC(9,5),
  ADD COLUMN IF NOT EXISTS current_lat   NUMERIC(9,5),
  ADD COLUMN IF NOT EXISTS current_lon   NUMERIC(9,5);

COMMENT ON COLUMN users.birth_lat   IS 'Geocoded latitude for birth_location';
COMMENT ON COLUMN users.birth_lon   IS 'Geocoded longitude for birth_location';
COMMENT ON COLUMN users.current_lat IS 'Geocoded latitude for current_location';
COMMENT ON COLUMN users.current_lon IS 'Geocoded longitude for current_location';


-- ============================================================
-- STEP 2: Create location_coords lookup table
-- Single source of truth for location string → lat/lon
-- Referenced by users, journeys, and future tables
-- On-save geocoding writes here first, then propagates
-- ============================================================

CREATE TABLE IF NOT EXISTS location_coords (
  location_string   TEXT PRIMARY KEY,
  lat               NUMERIC(9,5) NOT NULL,
  lon               NUMERIC(9,5) NOT NULL,
  resolved_name     TEXT,        -- human-readable confirmation of what was matched
  source            TEXT NOT NULL DEFAULT 'manual',  -- manual | nominatim | google
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE location_coords IS
  'Geocoded lat/lon lookup for all location strings in the platform.
   On-save trigger writes here, then propagates to users/journeys.';


-- ============================================================
-- STEP 3: Seed the 25 known locations
-- ============================================================

INSERT INTO location_coords (location_string, lat, lon, resolved_name, source)
VALUES

  -- United States — California
  ('Arcata, CA, US',           40.86650,  -124.08271, 'Arcata, Humboldt County, CA',         'manual'),
  ('Belmont, CA, US',          37.52021,  -122.27580, 'Belmont, San Mateo County, CA',        'manual'),
  ('Dublin, CA, US',           37.70215,  -121.93580, 'Dublin, Alameda County, CA',           'manual'),
  ('Fremont, CA, US',          37.54827,  -121.98857, 'Fremont, Alameda County, CA',          'manual'),
  ('Half Moon Bay, CA, US',    37.46357,  -122.42858, 'Half Moon Bay, San Mateo County, CA',  'manual'),
  ('Hayward, CA, US',          37.66882,  -122.08080, 'Hayward, Alameda County, CA',          'manual'),
  ('Milbrae, CA, US',          37.59967,  -122.38690, 'Millbrae, San Mateo County, CA',       'manual'),
  ('Oakland, CA, US',          37.80437,  -122.27080, 'Oakland, Alameda County, CA',          'manual'),
  ('Redwood City, CA, US',     37.48522,  -122.23635, 'Redwood City, San Mateo County, CA',   'manual'),
  ('Sacramento, CA, US',       38.58157,  -121.49440, 'Sacramento, CA',                       'manual'),
  ('San Francisco, CA, US',    37.77493,  -122.41942, 'San Francisco, CA',                    'manual'),
  ('San Mateo, CA, US',        37.56299,  -122.32553, 'San Mateo, San Mateo County, CA',      'manual'),
  ('Thousand Oaks, CA, US',    34.17056,  -118.83759, 'Thousand Oaks, Ventura County, CA',    'manual'),

  -- United States — Other states
  ('Chicago, IL, US',          41.85003,   -87.65005, 'Chicago, Cook County, IL',             'manual'),
  ('Houston, TX, US',          29.76328,   -95.36327, 'Houston, Harris County, TX',           'manual'),
  ('La Crosse, WI, US',        43.80136,   -91.23957, 'La Crosse, La Crosse County, WI',      'manual'),
  ('Miami, FL, US',            25.77427,   -80.19366, 'Miami, Miami-Dade County, FL',         'manual'),
  ('New York, NY, US',         40.71427,   -74.00597, 'New York City, NY',                    'manual'),

  -- India
  ('Delhi, India',             28.65195,    77.23149, 'Delhi, National Capital Territory',    'manual'),
  ('New Delhi, India',         28.63576,    77.22445, 'New Delhi, Capital of India',          'manual'),
  ('Gwalior, MP, India',       26.21124,    78.17337, 'Gwalior, Madhya Pradesh, India',       'manual'),

  -- Pakistan
  ('Pakistan',                 30.37532,    69.34515, 'Pakistan (country center)',             'manual'),
  ('Rawalpindi, Pakistan',     33.59733,    73.04790, 'Rawalpindi, Punjab, Pakistan',         'manual'),

  -- Fiji
  ('Sinatoka, Fiji',          -18.16667,   177.50000, 'Sigatoka (Singatoka), Fiji',           'manual'),
  ('Suva, Fiji',              -18.14161,   178.44149, 'Suva, Central Division, Fiji',         'manual')

ON CONFLICT (location_string) DO NOTHING;


-- ============================================================
-- STEP 4: Populate users birth_lat/lon and current_lat/lon
-- Joins users to location_coords on location string
-- ============================================================

-- Birth coordinates
UPDATE users u
SET    birth_lat = lc.lat,
       birth_lon = lc.lon,
       updated_at = NOW()
FROM   location_coords lc
WHERE  TRIM(u.birth_location) = lc.location_string
  AND  u.birth_location IS NOT NULL;

-- Current coordinates
UPDATE users u
SET    current_lat = lc.lat,
       current_lon = lc.lon,
       updated_at  = NOW()
FROM   location_coords lc
WHERE  TRIM(u.current_location) = lc.location_string
  AND  u.current_location IS NOT NULL;


-- ============================================================
-- STEP 5: Add lat/lon columns to journeys table
-- ============================================================

ALTER TABLE journeys
  ADD COLUMN IF NOT EXISTS lat  NUMERIC(9,5),
  ADD COLUMN IF NOT EXISTS lon  NUMERIC(9,5);

-- Populate journeys coordinates from lookup
UPDATE journeys j
SET    lat = lc.lat,
       lon = lc.lon
FROM   location_coords lc
WHERE  TRIM(j.location_name) = lc.location_string
  AND  j.location_name IS NOT NULL;


-- ============================================================
-- STEP 6: Create geocode trigger function
-- Called whenever a user saves birth_location or
-- current_location — looks up location_coords first,
-- updates the lat/lon columns immediately.
-- If location not found in lookup, inserts NULL
-- (Edge Function will fill it in asynchronously).
-- ============================================================

CREATE OR REPLACE FUNCTION sync_user_coordinates()
RETURNS TRIGGER AS $$
BEGIN
  -- Birth location changed
  IF NEW.birth_location IS DISTINCT FROM OLD.birth_location THEN
    SELECT lat, lon INTO NEW.birth_lat, NEW.birth_lon
    FROM   location_coords
    WHERE  location_string = TRIM(NEW.birth_location)
    LIMIT  1;
  END IF;

  -- Current location changed
  IF NEW.current_location IS DISTINCT FROM OLD.current_location THEN
    SELECT lat, lon INTO NEW.current_lat, NEW.current_lon
    FROM   location_coords
    WHERE  location_string = TRIM(NEW.current_location)
    LIMIT  1;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Attach trigger to users table
DROP TRIGGER IF EXISTS trg_sync_user_coordinates ON users;

CREATE TRIGGER trg_sync_user_coordinates
  BEFORE UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION sync_user_coordinates();

COMMENT ON FUNCTION sync_user_coordinates() IS
  'Automatically resolves lat/lon from location_coords when
   a user saves their birth or current location.
   New locations not in the lookup table will be geocoded
   asynchronously by the Edge Function and added to location_coords.';


-- ============================================================
-- STEP 7: Also apply trigger logic to journeys
-- ============================================================

CREATE OR REPLACE FUNCTION sync_journey_coordinates()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.location_name IS DISTINCT FROM OLD.location_name THEN
    SELECT lat, lon INTO NEW.lat, NEW.lon
    FROM   location_coords
    WHERE  location_string = TRIM(NEW.location_name)
    LIMIT  1;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trg_sync_journey_coordinates ON journeys;

CREATE TRIGGER trg_sync_journey_coordinates
  BEFORE UPDATE ON journeys
  FOR EACH ROW
  EXECUTE FUNCTION sync_journey_coordinates();


-- ============================================================
-- VERIFICATION QUERIES
-- Run these after the file to confirm coordinates landed
-- ============================================================

-- How many users have birth coordinates?
SELECT
  COUNT(*)                                          AS total_users,
  COUNT(birth_lat)                                  AS have_birth_coords,
  COUNT(current_lat)                                AS have_current_coords,
  COUNT(birth_lat) + COUNT(current_lat)             AS total_coord_points,
  COUNT(CASE WHEN birth_lat IS NOT NULL
              AND current_lat IS NOT NULL
              AND birth_location != current_location
             THEN 1 END)                            AS drawable_arcs
FROM users;

-- Sample — show the arc-ready records
SELECT
  user_id, full_name, cultural_origin,
  birth_location,   ROUND(birth_lat::numeric,3)   AS blat, ROUND(birth_lon::numeric,3)   AS blon,
  current_location, ROUND(current_lat::numeric,3) AS clat, ROUND(current_lon::numeric,3) AS clon
FROM users
WHERE birth_lat IS NOT NULL
  AND current_lat IS NOT NULL
ORDER BY full_name
LIMIT 20;
