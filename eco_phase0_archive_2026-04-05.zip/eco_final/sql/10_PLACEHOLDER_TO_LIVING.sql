-- ============================================================
-- EternalCurrent.Online — Phase 0 Status Fix
-- File: 10_PLACEHOLDER_TO_LIVING.sql
-- Generated: 2026-04-04
--
-- All 49 Placeholder records are real family members
-- with thin data — not system stubs.
-- Thin data is a product feature, not a different
-- category of person.
-- Changing all Placeholder → Living.
-- ============================================================

-- Preview before running (optional — run this SELECT first
-- to confirm the 49 records you are about to update):
SELECT user_id, full_name, status, tier
FROM users
WHERE status = 'Placeholder'
ORDER BY last_name, first_name;

-- ============================================================
-- THE UPDATE
-- ============================================================

UPDATE users
SET    status     = 'Living',
       updated_at = NOW()
WHERE  status = 'Placeholder';

-- ============================================================
-- Verify: should return 0 rows
-- ============================================================

SELECT COUNT(*) AS remaining_placeholders
FROM   users
WHERE  status = 'Placeholder';

-- ============================================================
-- Final status distribution — should show:
-- Living: 87 (original 38 + 49 former Placeholders)
-- Passed: 17
-- ============================================================

SELECT   status, COUNT(*) AS count
FROM     users
GROUP BY status
ORDER BY status;
