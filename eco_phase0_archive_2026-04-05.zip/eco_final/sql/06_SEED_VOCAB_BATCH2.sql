-- ============================================================
-- EternalCurrent.Online -- Vocab Library Seed Batch 2
-- Generated: 2026-04-04
--
-- New languages and additions:
-- Hindi: Bhanja, Bhanji, Bhatija, Bhatiji
-- Fijian Hindi: Dada, Dadi
-- English: generational kinship system, cousin terminology
-- Spanish/Hispanic: full kinship vocabulary
-- Dominican Spanish: regional variants
-- Italian (North): full kinship vocabulary
-- Marathi: full kinship vocabulary
-- ============================================================

INSERT INTO cultural_vocab_library
  (term, language, cultural_origin, definition, usage_example,
   contributor_id, reviewed, visible_to, network_id)
VALUES

  -- ============================================================
  -- HINDI — NEPHEW AND NIECE TERMS
  -- Hindi precisely distinguishes whose child you are referring to
  -- ============================================================

  (
    'Bhatija',
    'Hindi', 'India',
    'Brother''s son — nephew through your brother. Hindi makes a precise distinction between a nephew who comes through your brother versus your sister. Bhatija is the male child of your brother, carrying your own family line forward.',
    'My Bhatija started school this year — watching my brother become a father was something else entirely.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Bhatiji',
    'Hindi', 'India',
    'Brother''s daughter — niece through your brother. The female child of your brother. The -i suffix consistently marks the feminine in these nephew/niece pairs.',
    'Bhatiji has her father''s eyes and her mother''s stubbornness — which is to say she will be remarkable.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Bhanja',
    'Hindi', 'India',
    'Sister''s son — nephew through your sister. Distinct from Bhatija because the relationship crosses family lines at marriage. Your sister''s son belongs to another household but never to another heart.',
    'Bhanja came to stay with us every summer — my sister''s child in our home felt like the family completing a circle.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Bhanji',
    'Hindi', 'India',
    'Sister''s daughter — niece through your sister. The female child of your sister. Where English collapses nephew and niece into two words regardless of which sibling they come from, Hindi holds four distinct terms for the four possibilities.',
    'Bhanji called me by name the first time she ever said my name out loud. After that I was just Chacha.',
    NULL, TRUE, 'all', NULL
  ),


  -- ============================================================
  -- FIJIAN HINDI — DADA AND DADI
  -- Used by Fijian Indian families and confirmed in Indo-Caribbean
  -- communities alongside the older Bhojpuri Aja/Aji terms
  -- ============================================================

  (
    'Dada',
    'Fijian Hindi', 'Fiji',
    'Paternal grandfather in Fijian Hindi — father''s father. Used alongside the older Bhojpuri-origin term "Aja" in Fijian Indian families, with Dada being the more widely used standard Hindi form that the community also adopted. Both terms exist in the same households, sometimes across generations — grandchildren may use one, great-grandchildren another.',
    'Some of us called him Dada, the older ones called him Aja — he answered to both without missing a beat.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Dadi',
    'Fijian Hindi', 'Fiji',
    'Paternal grandmother in Fijian Hindi — father''s mother. The feminine counterpart to Dada, used alongside "Aji" in Fijian Indian families. The coexistence of Dadi and Aji in the same community is itself a record of the community''s layered history — Bhojpuri roots preserved in one word, standard Hindi adoption visible in the other.',
    'Dadi kept everything: the recipes, the songs, the names of people she had not seen in forty years.',
    NULL, TRUE, 'all', NULL
  ),


  -- ============================================================
  -- ENGLISH — GENERATIONAL KINSHIP SYSTEM
  -- For families where English is the primary language, and for
  -- the ECO platform''s cross-cultural navigation layer
  -- ============================================================

  (
    'Grandfather',
    'English', NULL,
    'Father''s father or mother''s father — the male grandparent. English does not distinguish which side of the family a grandparent comes from, collapsing the Hindi Dada/Nana distinction into a single term. This is one of the most common places where diaspora families find that English is not precise enough.',
    'He was just Grandfather in English — but in the house he was Nana to some and Dada to others, and those were not the same word.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Grandmother',
    'English', NULL,
    'Father''s mother or mother''s mother — the female grandparent. Like Grandfather, the term erases the maternal/paternal distinction that many other languages hold precisely. The informal versions Grandma, Granny, Gran, Nana, Nan vary widely by family and region.',
    'She was Grandmother to the world. To us she was Dadi, and that carried something Grandmother never quite could.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Great-Grandfather',
    'English', NULL,
    'The father of a grandparent — one generation above grandparent. English adds "Great-" to mark each generation further back: Great-Grandfather, Great-Great-Grandfather, Great-Great-Great-Grandfather, and so on. Each additional "Great-" equals one additional generation removed from the grandparent.',
    'We have one photograph of my Great-Grandfather. He is standing in a field somewhere in Punjab and he is not smiling — but his eyes are.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Great-Grandmother',
    'English', NULL,
    'The mother of a grandparent. The female counterpart to Great-Grandfather. The "Great-" prefix system is English''s way of acknowledging generational depth while avoiding the precise vocabulary that other languages build into the terms themselves.',
    'My Great-Grandmother arrived in Fiji on a ship whose name nobody remembers. We remember her name.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Great-Great-Grandfather',
    'English', NULL,
    'Two generations above grandparent — the grandfather of a grandparent. Each "Great-" marks one additional step back. This is typically the furthest generation that living family members can name from personal knowledge, and often marks the edge of oral family memory.',
    'Great-Great-Grandfather is where the names run out in most families. ECO was built in part to push that line back.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Uncle',
    'English', NULL,
    'A parent''s brother, or the husband of a parent''s sibling. English uses one word where Hindi uses at least six (Chacha, Tau, Mama, Fufa, Mausa, and their variants). The compression of all those relationships into "Uncle" is one of the most cited examples of what diaspora families lose when they shift to English.',
    'He was Uncle in every school form and every introduction. At home he was Chacha, which meant something completely different.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Aunt',
    'English', NULL,
    'A parent''s sister, or the wife of a parent''s sibling. As with Uncle, the English term collapses distinctions that are structurally preserved in South Asian, East Asian, and many other language families. Bua, Mausi, Chachi, Tai, Mami — all of these become simply "Aunt."',
    'In English she was Aunt. The word gave no clue that she was my father''s sister, which in our culture was a different kind of love than my mother''s sister would have been.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Cousin',
    'English', NULL,
    'The child of an aunt or uncle. English uses a single term for all cousins regardless of whether they come from the maternal or paternal side, whether they are older or younger, and whether they are connected through a brother or sister. Most other languages in the world do not do this — they carry the relationship''s full structure in the word itself.',
    'Cousins. One word, twelve people at the table, and not one of those relationships the same as another.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Cousin Brother',
    'English', NULL,
    'South Asian English term for a male cousin treated with the closeness of a brother. Widely used across India, Pakistan, Bangladesh, and diaspora communities as a way of preserving the emotional weight of a close cousin relationship that a plain "cousin" does not convey. Neither fully standard English nor a translation — it is a diaspora coinage.',
    'He''s not my brother but I''d call him Cousin Brother to anyone who asked, because cousin alone doesn''t say enough.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Cousin Sister',
    'English', NULL,
    'South Asian English term for a female cousin treated with the closeness of a sister. The female counterpart to Cousin Brother. Both terms are examples of diaspora communities expanding English to carry meaning that English alone cannot hold.',
    'My Cousin Sister and I grew up in different countries and still finished each other''s sentences when we finally met.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'First Cousin',
    'English', NULL,
    'The child of your parent''s sibling — the baseline cousin relationship. Your aunt''s or uncle''s children are your first cousins. This is what most people mean when they simply say "cousin" without qualification.',
    'First cousins are the ones you grew up with at every holiday. Second cousins are the ones you meet at weddings and spend the rest of the night trying to map.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Second Cousin',
    'English', NULL,
    'The child of your parent''s first cousin. You and your second cousin share great-grandparents but not grandparents. Second cousins are two generations removed from the shared ancestor at the same generational level.',
    'My mother knew her second cousins by name. I know them as faces at the reunion who are somehow family.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Cousin Once Removed',
    'English', NULL,
    'A cousin who is one generation away from you on the family tree — either one generation up (your parent''s cousin, who is your first cousin once removed) or one generation down (your first cousin''s child). "Removed" counts generational steps, not closeness. Your parent''s first cousin is your first cousin once removed. That person''s child is your second cousin.',
    'The "once removed" math confuses most people — including people whose families use it. The short version: once removed means one generation separates you from the cousin level.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Cousin Twice Removed',
    'English', NULL,
    'A cousin separated by two generational steps. Your grandparent''s first cousin is your first cousin twice removed. Your first cousin''s grandchild is also your first cousin twice removed. The "twice removed" system extends indefinitely — three times removed, four times removed — but in practice most families stop keeping track beyond once removed.',
    'At some point in the "removed" count, the math becomes an abstraction and the relationship becomes simply: family.',
    NULL, TRUE, 'all', NULL
  ),


  -- ============================================================
  -- SPANISH / HISPANIC — FULL KINSHIP VOCABULARY
  -- Core terms used across all Spanish-speaking communities.
  -- Dominican-specific variants noted inline where they differ.
  -- ============================================================

  (
    'Abuelo / Abuela',
    'Spanish', NULL,
    'Grandfather / Grandmother. Unlike Hindi, Spanish does not distinguish maternal from paternal grandparents in the base term — Abuelo covers both grandfathers and Abuela both grandmothers. The affectionate diminutives Abuelito and Abuelita are extremely common in everyday speech across all Spanish-speaking communities.',
    'Abuelita was the first one up and the last one to bed. The house ran on her schedule, even after she said it didn''t.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Bisabuelo / Bisabuela',
    'Spanish', NULL,
    'Great-grandfather / Great-grandmother. Spanish uses the prefix "bis-" to mark one generation above grandparent, equivalent to the English "Great-." Bisabuelo is widely understood across all Spanish-speaking communities and is used in both formal and everyday speech.',
    'My Bisabuela came from a village whose name nobody can spell anymore in the family. We keep her photograph instead.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Tatarabuelo / Tatarabuela',
    'Spanish', NULL,
    'Great-great-grandfather / Great-great-grandmother. Two generations above grandparent. Spanish extends the prefix system: bis- for great, tatarabuelo for great-great. Beyond this, families typically use circumlocutions rather than a standard term.',
    'Tatarabuelo is usually the name at the edge of family memory — the generation that requires a photograph and a story to feel real.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Tío / Tía',
    'Spanish', NULL,
    'Uncle / Aunt. Spanish does not distinguish whether a Tío is a paternal or maternal uncle, or whether they are a blood relative or an in-law — the term covers all. In Dominican Republic, Puerto Rico, and parts of Cuba, Tío and Tía are also used informally as terms of warmth for close family friends and trusted adults who are not blood relatives.',
    'Every adult at the party was Tío or Tía. Blood had nothing to do with it — affection and history did.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Primo / Prima',
    'Spanish', NULL,
    'Male cousin / Female cousin. Spanish genders cousin by the person being referred to, not by the speaker. Unlike English, which has one cousin term, Spanish has two — but like English it does not distinguish first, second, or degree of removal in the base term. In everyday speech "primo" and "prima" cover all cousins regardless of degree.',
    'I have twenty-three primos on my father''s side. I have learned not to explain this to people who grew up with two.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Sobrino / Sobrina',
    'Spanish', NULL,
    'Nephew / Niece. Spanish genders nephew and niece but, like the Tío/Tía system, does not distinguish whether the child comes through a brother or a sister. One term for all nephews, one for all nieces.',
    'She called all of her sisters'' and brothers'' children sobrinos, and she knew every birthday.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Padrino / Madrina',
    'Spanish', NULL,
    'Godfather / Godmother. A sacred kinship role in Hispanic culture — not merely ceremonial but a real second-parent relationship created at baptism (and sometimes at other milestones like quinceañera or confirmation). The compadre/comadre relationship between the godparent and the child''s parents creates a parallel bond between adults. In Dominican culture and across Latin America, padrinos are often among the most trusted adults in a child''s life.',
    'Padrino was at every graduation, every crisis, every Sunday dinner. That is what the role is. That is what it has always been.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Compadre / Comadre',
    'Spanish', NULL,
    'The relationship between a child''s parents and their godparents — co-parents in the fullest sense. When you ask someone to be your child''s padrino or madrina, you become their compadre or comadre. This creates a bond between adults that is as significant as the bond between godparent and child. The word compadre has traveled into English as a term for a close friend, but its root meaning is richer.',
    'My parents and my padrino''s family are compadres. That word means they would do anything for each other, and they have.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Cuñado / Cuñada',
    'Spanish', NULL,
    'Brother-in-law / Sister-in-law. Covers both the spouse''s sibling and the sibling''s spouse. Spanish does not distinguish these two directions the way some other languages do.',
    'My cuñada has been in this family longer than some of our blood relatives have paid attention to it.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Suegro / Suegra',
    'Spanish', NULL,
    'Father-in-law / Mother-in-law. Distinct words for in-law parents — Spanish does not attach "-in-law" to an existing term but creates separate vocabulary entirely.',
    'My suegra taught me to cook the things my husband missed from home. That is a kind of love that has no other word.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Mijo / Mija',
    'Spanish', NULL,
    'Contraction of "mi hijo / mi hija" — my son / my daughter — but used far more broadly as a term of deep affection for any younger person you feel close to. An abuela uses it for grandchildren. A neighbor uses it for a child she has known since birth. In Dominican Republic and Puerto Rico it carries particular warmth and is among the most common terms of endearment between adults and children.',
    'She called everyone younger than her mija. If she called you mija, you were taken care of.',
    NULL, TRUE, 'all', NULL
  ),


  -- ============================================================
  -- DOMINICAN SPANISH — REGIONAL VARIANTS
  -- Standard Spanish terms apply; notes on Dominican usage below
  -- ============================================================

  (
    'Papi / Mami',
    'Dominican Spanish', NULL,
    'Father / Mother in everyday Dominican speech — but in Dominican Republic culture these terms travel beyond their literal meaning. Papi and Mami are used as general terms of endearment between close friends, partners, and even strangers in the right context. The same word that a child uses for their father becomes what a wife calls her husband, what friends call each other on the street. It signals warmth, not just parentage.',
    'She called him Papi and he was not her father — that is Dominican, and you know what it means the moment you hear it.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Yaya / Yayo',
    'Dominican Spanish', NULL,
    'Grandmother / Grandfather in informal Dominican and broader Caribbean Spanish usage — affectionate diminutive alternatives to Abuela/Abuelo. Yaya and Yayo are warmer, more intimate versions, the kind children use and adults keep using because they cannot stop. Widely used in the Dominican Republic and Puerto Rico.',
    'Abuela was her formal title. To us she was Yaya, which is the same word said with your whole chest.',
    NULL, TRUE, 'all', NULL
  ),


  -- ============================================================
  -- ITALIAN — FULL KINSHIP VOCABULARY (Northern Italian)
  -- Standard Italian terms; regional dialect notes included
  -- ============================================================

  (
    'Nonno / Nonna',
    'Italian', NULL,
    'Grandfather / Grandmother. Unlike many languages, Italian Nonno and Nonna are used for grandparents on both sides of the family — there is no separate term for maternal versus paternal grandparents. Grandchildren use Nonno and Nonna as direct address, the same way English speakers say "Grandpa" and "Grandma." In Northern Italian dialects one may also hear regional variants like Nono and Nona.',
    'Every Sunday at Nonna''s. That is not a memory for Italian families — it is an institution.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Bisnonno / Bisnonna',
    'Italian', NULL,
    'Great-grandfather / Great-grandmother. The "bis-" prefix works the same way in Italian as in Spanish — both languages trace back to the Latin "bis" (twice). Great-grandparents in Italian family culture are often living presences in family stories even when they are long gone, kept alive through food, gestures, and the stories Nonna tells.',
    'Bisnonno left Northern Italy during the war and never went back. We still make his bread.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Pronipote',
    'Italian', NULL,
    'Great-grandchild — and also the plural pronipoti means descendants. In Italian the same root word nipote covers both grandchild and nephew/niece; pronipote extends that ambiguity to great-grandchild and great-nephew/niece. Context makes the meaning clear. Notably, pronipoti is also the Italian name for the cartoon family The Jetsons — descendants.',
    'When Nonno talked about the pronipoti he would someday have, he was talking about a kind of future that made the present worth everything.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Zio / Zia',
    'Italian', NULL,
    'Uncle / Aunt. Italian Zio and Zia cover all aunts and uncles regardless of whether they are paternal or maternal, blood relatives or in-laws. In modern Italian, especially among younger generations, Zio (and its clipped form Zi'') is used informally among close friends — similar to how "bro" operates in English. In Italian the Z makes the sound of the Spanish T in Tío/Tía — both languages preserve the Latin root.',
    'Zia arrived and the room got louder. That is a universal Italian truth.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Cugino / Cugina',
    'Italian', NULL,
    'Male cousin / Female cousin. Like Spanish primo/prima, Italian genders the cousin term but does not distinguish first from second cousins in the base word. The Sunday family gathering — la domenica in famiglia — typically includes the cugini as a natural part of the family group, not as occasional visitors.',
    'The cugini were at every Sunday dinner. The table was never the right size, and that was never going to change.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Nipote',
    'Italian', NULL,
    'A single Italian word that means nephew, niece, grandson, or granddaughter depending on context. The gender article distinguishes male (il nipote) from female (la nipote) but the word itself does not change. This ambiguity is one of the most distinctive features of Italian kinship vocabulary — and it reflects something real about Italian family life, where grandchildren and nieces/nephews occupy an equally cherished place.',
    'He asked about i miei nipoti and I had to clarify — grandchildren or nieces and nephews? In Italian you cannot always tell, and maybe that is the point.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Cognato / Cognata',
    'Italian', NULL,
    'Brother-in-law / Sister-in-law. From the Latin cognatus — related by birth. The Italian word for in-law siblings carries the Latin root for blood relation, which is either ironic or intentional depending on how close your family is.',
    'My cognata has been in this family for thirty years. At some point the "in-law" part stops mattering.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Suocero / Suocera',
    'Italian', NULL,
    'Father-in-law / Mother-in-law. As in Spanish, Italian creates distinct vocabulary for in-law parents rather than modifying the existing parent terms. La suocera is one of the most storied figures in Italian culture — the subject of a thousand jokes, the keeper of a thousand recipes, and often the actual operational head of the extended family.',
    'La suocera did not ask how you were doing. She observed, assessed, and then fed you until the answer changed.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Genero / Nuora',
    'Italian', NULL,
    'Son-in-law / Daughter-in-law. Italian gives these relationships their own complete words — Genero for the man who marries your daughter, Nuora for the woman who marries your son. La nuora in Italian family culture carries particular significance — she is the woman who enters the family and whose relationship with la suocera is one of the most observed bonds in the household.',
    'She became la nuora and inherited all of its meaning — the warmth, the expectation, the recipes she was required to learn.',
    NULL, TRUE, 'all', NULL
  ),


  -- ============================================================
  -- MARATHI — FULL KINSHIP VOCABULARY
  -- Maharashtra, India — Southern Indo-Aryan language
  -- ============================================================

  (
    'Ajoba',
    'Marathi', 'India',
    'Grandfather in Marathi — used for grandparents on both sides of the family, though "Aajoba" more precisely refers to the paternal grandfather in some contexts. Ajoba is one of the most distinctly Marathi kinship terms, immediately recognizable as different from the Hindi Dada/Nana system. The Marathi family system blends Northern (Sanskrit-influenced) and Southern traditions.',
    'Ajoba was working in the garden at eighty-two. He said stopping was not something he planned to do.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Aaji',
    'Marathi', 'India',
    'Grandmother in Marathi — deeply affectionate, widely used across Maharashtra and in Marathi diaspora communities. Like Ajoba, Aaji is one of the signature terms that immediately identifies a Marathi-speaking family. The word carries enormous warmth and is among the first words Marathi children learn.',
    'Aaji told the stories. Not just family stories — the old ones, the ones with gods in them, the ones that explained things.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Kaka',
    'Marathi', 'India',
    'Father''s brother in Marathi — paternal uncle. Shared with Hindi but carries a slightly broader usage in Marathi, where Kaka can also be used respectfully for any older male in a community, not just family. The Marathi kinship system, influenced by both Northern and Southern Indian traditions, gives the paternal uncle a particularly significant role.',
    'Kaka was the one you went to when you needed something explained that Baba wouldn''t discuss.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Kaku',
    'Marathi', 'India',
    'Wife of the Kaka — father''s brother''s wife. The female counterpart to the paternal uncle in Marathi. Kaku is a warm, domestic term — the aunt who is present in the daily life of the household, the one who knew what was happening in the kitchen before anyone else did.',
    'Kaku''s house smelled like the same spices every time. Twenty years later that smell still means safety.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Atya',
    'Marathi', 'India',
    'Father''s sister in Marathi — the paternal aunt. This is the Marathi equivalent of the Hindi Bua. Atya holds a special place in Marathi family structure — she left the household at marriage but maintains a deep bond with her birth family, especially in the observance of the Bhaubeej festival celebrating the brother-sister bond.',
    'Atya traveled back every year for Bhaubeej. Some distances are not measured in kilometers.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Mavshi',
    'Marathi', 'India',
    'Mother''s sister in Marathi — the maternal aunt. Equivalent to the Hindi Mausi. In Marathi, a step-mother is sometimes also called "Savatra Ai" or "Mawashi" — a linguistic overlap that speaks to how the maternal aunt''s nurturing role was sometimes close enough to a mother''s that the words touched.',
    'Mavshi was always the softer version of my mother. Same blood, different volume.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Vahini',
    'Marathi', 'India',
    'Elder brother''s wife in Marathi — equivalent to Bhabhi in Hindi but specifically for the elder brother''s wife. Marathi distinguishes this from the younger brother''s wife (Jaau). Vahini is a term of both respect and warmth — the woman who married your older brother and took on her place in the household hierarchy.',
    'Vahini was the one who held the family together during the year everything went wrong. That is what vahini means in practice.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Nanand',
    'Marathi', 'India',
    'Husband''s sister in Marathi — sister-in-law. The relationship between a wife and her nanand is one of the most nuanced in Marathi family life — it can be the most supportive bond in the household or the most complex, and Marathi literature has explored it at length. The equivalent term in Hindi is Nanad.',
    'My nanand was the first person in the family who made me feel I actually belonged there.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Bhau',
    'Marathi', 'India',
    'Brother in Marathi. Elder brother may be called Dada (a term shared with Hindi but meaning elder brother in Marathi rather than grandfather) or Motha Bhau. Bhau is the everyday term — direct, affectionate, fundamental to how Marathi families address each other.',
    'Bhau picked up the phone on the first ring, always. I never had to explain. He already knew.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Tai',
    'Marathi', 'India',
    'Elder sister in Marathi — a term of respect for an older sister. While Bahin is the general word for sister, Tai is specifically the elder sister, carrying the same generational respect encoded into the Hindi Didi. In Marathi communities this extends beyond blood — any older woman who occupies an elder sister role can be addressed as Tai.',
    'She was Tai to everyone in the building, not just to us. Some titles you earn past the family line.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Bhacha / Bhachi',
    'Marathi', 'India',
    'Nephew / Niece in Marathi — specifically the sister''s son (Bhacha) and the sister''s daughter (Bhachi). Like Hindi, Marathi distinguishes the niece/nephew relationship by which sibling the child comes through. The brother''s son is Putanya and the brother''s daughter is Putani, completing the four-way system.',
    'Bhachi sent her first letter in Marathi. Crooked handwriting, perfect grammar, total pride.',
    NULL, TRUE, 'all', NULL
  );

-- ============================================================
-- END OF VOCAB LIBRARY SEED BATCH 2
-- 57 new terms across 8 languages / language variants:
-- Hindi (4), Fijian Hindi (2), English (12),
-- Spanish/Hispanic (10), Dominican Spanish (2),
-- Italian (9), Marathi (11)
-- Running total: 36 (Batch 1) + 57 (Batch 2) = 93 terms
-- ============================================================
