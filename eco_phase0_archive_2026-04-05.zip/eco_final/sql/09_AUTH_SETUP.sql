-- ============================================================
-- EternalCurrent.Online — Phase 0 Auth Setup
-- File: 09_AUTH_SETUP.sql
-- Generated: 2026-04-04
--
-- Step 1: Add STAR email to users table
-- Step 2: After Vikas logs in via Supabase Auth,
--         run Step 2 to link the auth UUID to his user row.
-- ============================================================


-- ============================================================
-- STEP 1: Add STAR email
-- Run this now.
-- ============================================================

UPDATE users
SET email      = 'vikas@eternalcurrent.online',
    updated_at = NOW()
WHERE user_id  = 'STAR';

-- Verify:
SELECT user_id, full_name, email, auth_id
FROM users
WHERE user_id = 'STAR';


-- ============================================================
-- STEP 2: Link Supabase Auth UUID to STAR's user row
-- Run this AFTER Vikas has logged in at least once via
-- Supabase Auth (magic link or email+password).
-- Replace the placeholder UUID with the real one from:
-- Supabase dashboard → Authentication → Users → copy the UUID
-- next to vikas@eternalcurrent.online
-- ============================================================

-- UPDATE users
-- SET auth_id    = 'PASTE-SUPABASE-AUTH-UUID-HERE',
--     updated_at = NOW()
-- WHERE user_id  = 'STAR';

-- Verify after running Step 2:
-- SELECT user_id, full_name, email, auth_id FROM users WHERE user_id = 'STAR';
