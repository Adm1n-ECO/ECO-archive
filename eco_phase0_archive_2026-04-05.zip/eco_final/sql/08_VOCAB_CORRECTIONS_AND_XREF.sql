-- ============================================================
-- EternalCurrent.Online -- Vocab Library Corrections
-- and Cross-Language Overlap Updates
-- File: 08_VOCAB_CORRECTIONS_AND_XREF.sql
-- Generated: 2026-04-04
--
-- This file:
-- 1. Corrects confirmed errors from the self-check
-- 2. Adds the missing Punjabi Mama entry
-- 3. Flags the uncertain Bengali Nandai entry
-- 4. Adds cross-language overlap notes to all affected entries
--
-- All UPDATEs identify rows by (term, language) pair.
-- ============================================================


-- ============================================================
-- SECTION 1: CONFIRMED ERROR CORRECTIONS
-- ============================================================

-- ERROR: Bhanji usage example said "Chacha" (paternal uncle).
-- Bhanji is your SISTER's daughter. From her perspective,
-- her mother's brother is her MAMA — not Chacha.
-- Chacha is a paternal uncle (father's side).

UPDATE cultural_vocab_library
SET usage_example = 'Bhanji called me by name the first time she ever said my name out loud. After that I was just Mama.',
    updated_at = NOW()
WHERE term = 'Bhanji' AND language = 'Hindi';


-- UNCERTAIN TERM: Bengali Nandai
-- "Sister''s husband" — Bhagnipati is the verifiable formal term.
-- Nandai appears in some regional Bengali usage but is unconfirmed
-- as standard. Marking reviewed = FALSE pending native speaker
-- confirmation. Definition updated to note uncertainty.

UPDATE cultural_vocab_library
SET reviewed = FALSE,
    definition = 'Sister''s husband in Bengali — brother-in-law through a sister. NOTE: This entry is flagged for native speaker review. The formal Bengali term is Bhagnipati; Nandai appears in regional usage across parts of West Bengal but is not universally confirmed. ECO will update this entry when a Bengali speaker in the network can verify. The relationship itself — the man who marries your sister — is among the most warmly regarded in Bengali family life.',
    updated_at = NOW()
WHERE term = 'Nandai' AND language = 'Bengali';


-- ============================================================
-- SECTION 2: MISSING TERM — PUNJABI MAMA
-- ============================================================

-- Punjabi Mama (mother''s brother) was missing from Batch 3.
-- The term is used in Punjabi the same as Hindi, but the
-- Punjabi cultural context around Mama is distinct enough
-- to deserve its own entry.

INSERT INTO cultural_vocab_library
  (term, language, cultural_origin, definition, usage_example,
   contributor_id, reviewed, visible_to, network_id)
VALUES (
  'Mama',
  'Punjabi', 'India',
  'Mother''s brother in Punjabi — the maternal uncle. Mama is one of the most pan-South Asian kinship terms: the same word appears in Hindi, Punjabi, Gujarati, Bengali, and Marathi. In Tamil it appears as Maama; in Urdu as Mamu. In Punjabi, Mama occupies a particularly warm position in family life — he is your mother''s protector, which by extension makes him yours. The Punjabi Mama is often the figure who mediates between the maternal and paternal households. Cross-language note: this single term (or its close variant) is one of the most widely shared kinship words across South Asia — a rare case where the linguistic map and the cultural map align almost perfectly.',
  'Mama was the one who knew everything about our mother''s childhood. He had been there for all of it.',
  NULL, TRUE, 'all', NULL
);


-- ============================================================
-- SECTION 3: CROSS-LANGUAGE OVERLAP UPDATES
-- Grouped by relationship cluster.
-- Each UPDATE appends a "Cross-language note" sentence to the
-- existing definition so the overlap is visible in the
-- Confluence library.
-- ============================================================


-- ============================================================
-- CLUSTER A: MOTHER''S BROTHER
-- Hindi: Mama | Gujarati: Mama | Bengali: Mama
-- Tamil: Maama | Marathi: Mama | Punjabi: Mama (added above)
-- Urdu: Mamu | Fijian Hindi: Mama (used informally)
-- This is the most pan-South Asian kinship term in existence.
-- ============================================================

UPDATE cultural_vocab_library
SET definition = 'Mother''s brother. Not to be confused with the English "mama" — this is a male figure, often a close ally and protector of the mother''s children. Cross-language note: Mama is one of the most widely shared kinship terms across South Asia. The same word appears in Hindi, Punjabi, Gujarati, Bengali, and Marathi. In Tamil it becomes Maama; in Urdu, Mamu. Across all these communities the relationship is similar — the maternal uncle as protector of the mother''s lineage — which may explain why the word traveled so consistently across language boundaries.',
    updated_at = NOW()
WHERE term = 'Mama' AND language = 'Hindi';

UPDATE cultural_vocab_library
SET definition = 'Mother''s brother / his wife in Gujarati — the maternal uncle and his wife. Mama is shared across Gujarati, Hindi, Marathi, Bengali, Punjabi, and Tamil (as Maama) — one of the most consistently used kinship terms across all South Asian languages. In Urdu it appears as Mamu. In Gujarati, Mama''s house is often a second home — the maternal household that carries a different, softer warmth than the paternal one.',
    updated_at = NOW()
WHERE term = 'Mama / Mami' AND language = 'Gujarati';

UPDATE cultural_vocab_library
SET definition = 'Mother''s brother / his wife in Bengali — shared term across multiple South Asian languages. In Bengali, Mama is among the most affectionate of the extended family terms. The same word appears in Hindi, Punjabi, Gujarati, Marathi, and Tamil (as Maama), and in Urdu as Mamu — making this one of the most pan-South Asian kinship terms in existence. The maternal uncle is often a figure of fun and indulgence, contrasted with the more formal paternal uncles. Mami is his wife.',
    updated_at = NOW()
WHERE term = 'Mama / Mami' AND language = 'Bengali';

UPDATE cultural_vocab_library
SET definition = 'Mother''s brother / his wife in Tamil. Maama is shared across Tamil, Hindi, Gujarati, Bengali, Marathi, and Punjabi — a pan-South Asian term for the maternal uncle that appears in almost identical form across the entire subcontinent. In Urdu it is Mamu. In Tamil, the Maama relationship carries additional structural significance: in traditional Tamil kinship, Maama''s children are cross-cousins (Attan and Athangai) and were preferred marriage partners. Mami is his wife.',
    updated_at = NOW()
WHERE term = 'Maama / Mami' AND language = 'Tamil';


-- ============================================================
-- CLUSTER B: FATHER''S SISTER
-- Hindi: Bua | Urdu: Phupho | Gujarati: Foi/Fua
-- Bengali: Pishi/Pisimaa | Marathi: Atya
-- Punjabi: Bhua/Phuph | Tamil: Athai
-- Every South Asian language has a distinct word for this
-- relationship — one of the most culturally charged bonds
-- in South Asian family life.
-- ============================================================

UPDATE cultural_vocab_library
SET definition = 'Father''s sister. A uniquely cherished relationship — she left the family home at marriage but never left the family. Cross-language note: every major South Asian language has a distinct word for this relationship, which itself signals its cultural importance. In Urdu: Phupho. In Gujarati: Foi. In Bengali: Pishi. In Marathi: Atya. In Punjabi: Bhua. In Tamil: Athai. The relationship is culturally distinct from all other aunt relationships — the woman who was your father''s sister before she was anyone''s wife.',
    updated_at = NOW()
WHERE term = 'Bua' AND language = 'Hindi';

UPDATE cultural_vocab_library
SET definition = 'Father''s sister — the Urdu/Pakistani equivalent of the Hindi Bua. The same deep bond, expressed in a different tongue. Cross-language note: the father''s sister has a distinct term in every South Asian language — Hindi: Bua, Gujarati: Foi, Bengali: Pishi, Marathi: Atya, Punjabi: Bhua, Tamil: Athai. In Urdu and Pakistani communities, Phupho is the standard term though some households use the variant Phuppi.',
    updated_at = NOW()
WHERE term = 'Phupho' AND language = 'Urdu';

UPDATE cultural_vocab_library
SET definition = 'Father''s sister / her husband in Gujarati — the Gujarati equivalent of the Hindi Bua. Foi is a distinctly Gujarati term — also spelled Fua, Fui, or Phoi in different Gujarati communities. Fua is her husband. Cross-language note: the father''s sister cluster across South Asian languages — Hindi: Bua, Urdu: Phupho, Bengali: Pishi, Marathi: Atya, Punjabi: Bhua, Tamil: Athai — all describe the same bond: the woman who left the household at marriage but remained the family''s anchor. Foi''s children are addressed as Bhai or Ben in Gujarati — there is no separate cousin term.',
    updated_at = NOW()
WHERE term = 'Foi / Fua' AND language = 'Gujarati';

UPDATE cultural_vocab_library
SET definition = 'Father''s sister in Bengali — the paternal aunt. Pishi is a uniquely Bengali term for the relationship that Hindi calls Bua, Gujarati calls Foi, Urdu calls Phupho, Marathi calls Atya, Punjabi calls Bhua, and Tamil calls Athai. The relationship is the same across all these communities — the woman who was your father''s sister before she was anyone else''s wife — but Bengali gives it its own word, which is characteristic of how precisely Bengali kinship vocabulary is mapped. Pisimaa is the respectful form.',
    updated_at = NOW()
WHERE term = 'Pishi / Pisimaa' AND language = 'Bengali';

UPDATE cultural_vocab_library
SET definition = 'Father''s sister in Marathi — the paternal aunt. This is the Marathi equivalent of the Hindi Bua, Urdu Phupho, Gujarati Foi, Bengali Pishi, Punjabi Bhua, and Tamil Athai. Atya holds a special place in Marathi family structure — she left the household at marriage but maintains a deep bond with her birth family, especially in the observance of the Bhaubeej festival celebrating the brother-sister bond. In all South Asian languages, the father''s sister has her own distinct word — a linguistic fact that reflects how culturally significant this relationship is.',
    updated_at = NOW()
WHERE term = 'Atya' AND language = 'Marathi';

UPDATE cultural_vocab_library
SET definition = 'Father''s sister in Punjabi — the paternal aunt. Bhua in Punjabi, Bua in Hindi — the same deeply cherished relationship of the woman who left the household at marriage but never left the family. Cross-language note: the father''s sister has a distinct name in every South Asian language — Hindi: Bua, Urdu: Phupho, Gujarati: Foi, Bengali: Pishi, Marathi: Atya, Tamil: Athai. The consistency of this pattern across completely different language families (Indo-Aryan and Dravidian alike) tells you something about how universally important this relationship has been across South Asia. Also pronounced Phuph or Phuphi in some Punjabi households.',
    updated_at = NOW()
WHERE term = 'Bhua / Phuph' AND language = 'Punjabi';

UPDATE cultural_vocab_library
SET definition = 'Father''s sister in Tamil — the paternal aunt. Athai holds a particularly significant position in Tamil kinship structure: in traditional Tamil society, a cross-cousin marriage (marrying your Athai''s son or daughter) was not only permitted but preferred. Cross-language note: this relationship — the father''s sister — has a distinct term in every South Asian language: Hindi Bua, Urdu Phupho, Gujarati Foi, Bengali Pishi, Marathi Atya, Punjabi Bhua. Tamil''s Athai, however, carries the unique structural weight of the preferred marriage alliance system, making it one of the most culturally layered entries in the entire library.',
    updated_at = NOW()
WHERE term = 'Athai' AND language = 'Tamil';


-- ============================================================
-- CLUSTER C: MOTHER''S SISTER
-- Hindi: Mausi | Urdu: Khalah | Gujarati: Masi
-- Bengali: Mashi | Marathi: Mavshi | Punjabi: Maasi
-- Tamil: Periamma (elder) / Chitti (younger)
-- Tamil is the exception — it distinguishes seniority.
-- ============================================================

UPDATE cultural_vocab_library
SET definition = 'Mother''s sister. Often the person who knew your mother before she became your mother — a living archive of who she was. Cross-language note: the mother''s sister has a distinct word in every South Asian language — Gujarati: Masi, Bengali: Mashi, Marathi: Mavshi, Punjabi: Maasi, Urdu: Khalah. Tamil is the notable exception: it distinguishes between the elder sister (Periamma — literally "big mother") and the younger sister (Chitti), encoding seniority into the term itself. This is the one cluster where Tamil''s precision goes beyond what all the Indo-Aryan languages do.',
    updated_at = NOW()
WHERE term = 'Mausi' AND language = 'Hindi';

UPDATE cultural_vocab_library
SET definition = 'Mother''s sister — the Urdu/Pakistani equivalent of the Hindi Mausi. Two different words for the same irreplaceable presence. Cross-language note: Gujarati: Masi, Bengali: Mashi, Marathi: Mavshi, Punjabi: Maasi, Hindi: Mausi. Tamil distinguishes elder mother''s sister (Periamma) from younger (Chitti). In Arabic-origin Urdu, Khalah preserves the Arabic term for maternal aunt — a reminder that Urdu''s kinship vocabulary draws from both Sanskrit and Arabic roots.',
    updated_at = NOW()
WHERE term = 'Khalah' AND language = 'Urdu';

UPDATE cultural_vocab_library
SET definition = 'Mother''s sister / her husband in Gujarati — shared with Hindi Mausi/Mausa. Cross-language note: the mother''s sister cluster across South Asian languages — Hindi: Mausi, Urdu: Khalah, Bengali: Mashi, Marathi: Mavshi, Punjabi: Maasi. Tamil uniquely distinguishes seniority: Periamma for the elder sister, Chitti for the younger. In Gujarati, as in most Indo-Aryan languages, Masi covers both elder and younger maternal aunts without distinction. Masi was the person Maa called first. That is the only piece of information you need about their relationship.',
    updated_at = NOW()
WHERE term = 'Masi / Masa' AND language = 'Gujarati';

UPDATE cultural_vocab_library
SET definition = 'Mother''s sister in Bengali — the maternal aunt. Mashi is one of the most widely used extended family terms in Bengali. Cross-language note: mother''s sister across South Asian languages — Hindi: Mausi, Urdu: Khalah, Gujarati: Masi, Marathi: Mavshi, Punjabi: Maasi. Tamil uses Periamma for the elder maternal aunt and Chitti for the younger — the only language in this cluster to encode seniority. Like Kaku and Kaka, Mashi in Bengali carries the -ma suffix in its respectful form (Mashima), signaling that this woman is a mother-figure in the household.',
    updated_at = NOW()
WHERE term = 'Mashi / Mashima' AND language = 'Bengali';

UPDATE cultural_vocab_library
SET definition = 'Mother''s sister in Marathi — the maternal aunt. Equivalent to the Hindi Mausi. Cross-language note: the mother''s sister cluster — Hindi: Mausi, Urdu: Khalah, Gujarati: Masi, Bengali: Mashi, Punjabi: Maasi. Tamil distinguishes elder (Periamma) from younger (Chitti) maternal aunts. In Marathi, a step-mother is sometimes also called "Savatra Ai" or "Mawashi" — a linguistic overlap that speaks to how the maternal aunt''s nurturing role was sometimes close enough to a mother''s that the words touched.',
    updated_at = NOW()
WHERE term = 'Mavshi' AND language = 'Marathi';

UPDATE cultural_vocab_library
SET definition = 'Mother''s sister / her husband in Punjabi — the maternal aunt and her husband. Cross-language note: mother''s sister across South Asian languages — Hindi: Mausi, Urdu: Khalah, Gujarati: Masi, Bengali: Mashi, Marathi: Mavshi. Tamil distinguishes elder (Periamma) from younger (Chitti). In Punjabi, Maasi is one of the closest bonds in family life — she knew your mother before she was your mother, which gives her a unique authority on who your mother actually is. Maasad is her husband.',
    updated_at = NOW()
WHERE term = 'Maasi / Maasad' AND language = 'Punjabi';

UPDATE cultural_vocab_library
SET definition = 'Mother''s elder sister / Mother''s younger sister in Tamil. Periamma is "big mother" — the elder sister of your mother, who commands near-maternal respect. Chitti is the younger sister of your mother — more informal, often a close confidante. Cross-language note: Tamil is the only South Asian language in this cluster to encode seniority into the aunt term itself. All Indo-Aryan languages (Hindi: Mausi, Gujarati: Masi, Bengali: Mashi, Marathi: Mavshi, Punjabi: Maasi, Urdu: Khalah) use a single term for both elder and younger maternal aunts. Tamil''s precision here — Periamma vs Chitti — is one of the clearest illustrations of the Dravidian kinship system''s structural depth.',
    updated_at = NOW()
WHERE term = 'Periamma / Chitti' AND language = 'Tamil';


-- ============================================================
-- CLUSTER D: DADA COLLISION
-- In Hindi, Gujarati, Punjabi, Fijian Hindi: GRANDFATHER
-- In Bengali and Marathi: ELDER BROTHER
-- One of the most important cross-language collision notes
-- in the entire library.
-- ============================================================

UPDATE cultural_vocab_library
SET definition = 'Paternal grandfather — father''s father. A figure of authority and often the oral historian of the family. Cross-language collision note: Dada means paternal grandfather in Hindi, Gujarati, and Punjabi. However, in Bengali and Marathi, Dada means elder brother. This is one of the most consequential same-word collisions across South Asian languages — a Hindi speaker and a Bengali speaker using the word "Dada" are referring to completely different relationships. In Bengali, the paternal grandfather is Thakurda; in Marathi, Ajoba.',
    updated_at = NOW()
WHERE term = 'Dada' AND language = 'Hindi';

UPDATE cultural_vocab_library
SET definition = 'Paternal grandfather in Gujarati. Dada is the standard term; Bapuji is the more reverential form, carrying the weight of ancestral authority. Cross-language collision note: Dada means grandfather in Hindi, Gujarati, Punjabi, and Fijian Hindi — but in Bengali and Marathi, Dada means elder brother. A Gujarati family and a Bengali family using the word "Dada" are speaking about entirely different generations. In Bengali, the paternal grandfather is Thakurda; in Marathi, Ajoba.',
    updated_at = NOW()
WHERE term = 'Dada / Bapuji' AND language = 'Gujarati';

UPDATE cultural_vocab_library
SET definition = 'Paternal grandfather in Punjabi — father''s father. Dada is shared with Hindi but Punjabi families also use Babaji as an honorific form, particularly in Sikh households where the suffix -ji adds reverence. Cross-language collision note: Dada means grandfather in Punjabi, Hindi, Gujarati, and Fijian Hindi. However, in Bengali and Marathi, Dada means elder brother — not grandfather. The Bengali paternal grandfather is Thakurda; the Marathi grandfather is Ajoba. This collision is worth knowing for any family that spans multiple South Asian language communities.',
    updated_at = NOW()
WHERE term = 'Dada / Babaji' AND language = 'Punjabi';

UPDATE cultural_vocab_library
SET definition = 'Paternal grandfather in Fijian Hindi — father''s father. Used alongside the older Bhojpuri-origin term "Aja" in Fijian Indian families, with Dada being the more widely used standard Hindi form that the community also adopted. Cross-language collision note: Dada means grandfather in Fijian Hindi, Hindi, Gujarati, and Punjabi. In Bengali and Marathi, however, Dada means elder brother — a collision worth noting for Fijian Indian families who have members from Bengali or Marathi backgrounds.',
    updated_at = NOW()
WHERE term = 'Dada' AND language = 'Fijian Hindi';

-- Bengali Dada already has the collision note — no update needed.
-- Verify it is complete.

-- Marathi: add cross-reference to Dada collision in the Bhau entry
-- since Dada is referenced there.
UPDATE cultural_vocab_library
SET definition = 'Brother in Marathi. Elder brother may be called Dada (a term shared with Hindi in sound but carrying a completely different meaning — in Hindi Dada means paternal grandfather; in Marathi and Bengali, Dada means elder brother). Cross-language collision note: this Dada collision is one of the most important in the library — the same word means grandfather in Hindi, Gujarati, and Punjabi, and elder brother in Bengali and Marathi. Bhau picked up the phone on the first ring, always. I never had to explain. He already knew.',
    updated_at = NOW()
WHERE term = 'Bhau' AND language = 'Marathi';


-- ============================================================
-- CLUSTER E: TAI COLLISION
-- Hindi: wife of Tau (father''s elder brother''s wife)
-- Marathi: elder sister
-- ============================================================

UPDATE cultural_vocab_library
SET definition = 'Wife of the Tau (father''s older brother). The female counterpart to a senior paternal uncle. Cross-language collision note: Tai means the father''s elder brother''s wife in Hindi. However, in Marathi, Tai means elder sister — a completely different relationship. A Hindi speaker and a Marathi speaker using the word "Tai" are referring to different people in the family. As with the Dada collision, the same word travels across language boundaries carrying different cargo.',
    updated_at = NOW()
WHERE term = 'Tai' AND language = 'Hindi';

UPDATE cultural_vocab_library
SET definition = 'Elder sister in Marathi — a term of respect for an older sister. While Bahin is the general word for sister, Tai is specifically the elder sister, carrying the same generational respect encoded into the Hindi Didi. Cross-language collision note: Tai means elder sister in Marathi, but in Hindi, Tai refers to the wife of the Tau (father''s elder brother). The same word, two different languages, two different relationships. In Marathi communities this extends beyond blood — any older woman who occupies an elder sister role can be addressed as Tai.',
    updated_at = NOW()
WHERE term = 'Tai' AND language = 'Marathi';


-- ============================================================
-- CLUSTER F: ELDER BROTHER''S WIFE
-- Hindi: Bhabhi | Bengali: Boudi | Tamil: Anni
-- Marathi: Vahini | Gujarati: Bhabhi (same as Hindi)
-- Fijian Hindi: Jij (different meaning — see entry)
-- ============================================================

UPDATE cultural_vocab_library
SET definition = 'Brother''s wife — sister-in-law through a brother. Typically refers to the elder brother''s wife in common usage. Cross-language note: the elder brother''s wife has a distinct term in every South Asian language — Bengali: Boudi, Tamil: Anni, Marathi: Vahini, Gujarati: Bhabhi (shared with Hindi). In Fijian Hindi, Jij refers to an older sister or female cousin — a related but distinct usage. This relationship cluster is one of the most consistently named across South Asia: the woman who marries your elder brother and becomes part of the household hierarchy.',
    updated_at = NOW()
WHERE term = 'Bhabhi' AND language = 'Hindi';

UPDATE cultural_vocab_library
SET definition = 'Elder brother''s wife in Bengali — the sister-in-law through an elder brother. Boudi is a distinctly Bengali term with no direct equivalent in Hindi''s Bhabhi system in terms of its cultural weight. Cross-language note: the elder brother''s wife cluster across South Asian languages — Hindi: Bhabhi, Tamil: Anni, Marathi: Vahini, Gujarati: Bhabhi. Each term carries slightly different cultural weight — Boudi in Bengali is perhaps the most emotionally complex, given the literature and songs that exist around her role in the household.',
    updated_at = NOW()
WHERE term = 'Boudi' AND language = 'Bengali';

UPDATE cultural_vocab_library
SET definition = 'Elder brother''s wife in Tamil — sister-in-law through an elder brother. Cross-language note: the elder brother''s wife has a distinct term in every South Asian language — Hindi: Bhabhi, Bengali: Boudi, Marathi: Vahini, Gujarati: Bhabhi. In Tamil, the arrival of Anni into the household is governed by the same kinship logic as the Anna system: she enters at Anna''s level in the hierarchy, above all younger siblings. Anni was the one who remembered everyone''s birthday after Anna forgot his own.',
    updated_at = NOW()
WHERE term = 'Anni' AND language = 'Tamil';

UPDATE cultural_vocab_library
SET definition = 'Elder brother''s wife in Marathi — equivalent to Bhabhi in Hindi but specifically for the elder brother''s wife. Marathi distinguishes this from the younger brother''s wife (Jaau). Cross-language note: the elder brother''s wife cluster across South Asian languages — Hindi: Bhabhi, Bengali: Boudi, Tamil: Anni, Gujarati: Bhabhi (shared with Hindi). Vahini is a term of both respect and warmth — the woman who married your older brother and took on her place in the household hierarchy.',
    updated_at = NOW()
WHERE term = 'Vahini' AND language = 'Marathi';


-- ============================================================
-- CLUSTER G: MATERNAL GRANDPARENTS
-- Hindi/Gujarati/Punjabi: Nana (grandfather) / Nani (grandmother)
-- Bengali: Dadu / Dida
-- Marathi/Tamil: same term for both sides (Ajoba/Aaji, Thatha/Paati)
-- ============================================================

UPDATE cultural_vocab_library
SET definition = 'Maternal grandfather — mother''s father. Often experienced differently from Dada — the maternal household carries a softer, more indulgent warmth in many families. Cross-language note: Nana for maternal grandfather is shared across Hindi, Gujarati, and Punjabi. Bengali uses Dadu instead. In Marathi and Tamil, the same term is used for both paternal and maternal grandfathers (Ajoba and Thatha respectively) — a structural difference between the Indo-Aryan and Dravidian approaches to grandparent terminology.',
    updated_at = NOW()
WHERE term = 'Nana' AND language = 'Hindi';

UPDATE cultural_vocab_library
SET definition = 'Maternal grandfather / maternal grandmother in Punjabi — shared terms with Hindi. The maternal grandparent household (Nanihal) carries a particular quality in Punjabi culture — looser, more indulgent, the place where grandchildren go to be spoiled. Cross-language note: Nana and Nani for maternal grandparents are shared across Punjabi, Hindi, and Gujarati. Bengali uses Dadu (grandfather) and Dida (grandmother) for the maternal side instead. Marathi uses Ajoba for both sides; Tamil uses Thatha for both. Nanihal was where the rules relaxed. Nani said yes to things Dadi never would.',
    updated_at = NOW()
WHERE term = 'Nana / Nani' AND language = 'Punjabi';

UPDATE cultural_vocab_library
SET definition = 'Maternal grandfather / maternal grandmother in Bengali — mother''s father and mother''s mother. Dadu and Dida are among the most beloved terms in Bengali family vocabulary. Cross-language note: while Hindi, Gujarati, and Punjabi use Nana (grandfather) and Nani (grandmother) for the maternal grandparents, Bengali uses the completely different Dadu and Dida. In some Bengali families Dadu is also used for the paternal grandfather — the specific term varies by family and regional tradition. The maternal grandparent household in Bengali is called Didibari, carrying its own distinct warmth.',
    updated_at = NOW()
WHERE term = 'Dadu / Dida' AND language = 'Bengali';

UPDATE cultural_vocab_library
SET definition = 'Grandfather in Marathi — used for grandparents on both sides of the family. Cross-language note: Marathi uses the same term Ajoba for both paternal and maternal grandfather, unlike Hindi/Punjabi/Gujarati which distinguish Dada (paternal) from Nana (maternal). Tamil similarly uses Thatha for both sides. Bengali distinguishes them completely — Thakurda (paternal) and Dadu (maternal). Marathi sits between these systems, making it an interesting bridge in how South Asian languages approach grandparent vocabulary.',
    updated_at = NOW()
WHERE term = 'Ajoba' AND language = 'Marathi';

UPDATE cultural_vocab_library
SET definition = 'Grandfather / Grandmother in Tamil — used for grandparents on both sides of the family in everyday speech. Cross-language note: Tamil uses Thatha for both paternal and maternal grandfather and Paati for both grandmothers — unlike Hindi, Gujarati, and Punjabi which distinguish paternal (Dada/Dadi) from maternal (Nana/Nani). Marathi similarly uses Ajoba for both sides. Bengali makes the sharpest distinction of all: Thakurda (paternal grandfather) vs Dadu (maternal grandfather), and Thakuma vs Dida for grandmothers.',
    updated_at = NOW()
WHERE term = 'Thatha / Paati' AND language = 'Tamil';


-- ============================================================
-- CLUSTER H: EUROPEAN BIS- PREFIX (Great-Grandparent)
-- Spanish: Bisabuelo / Bisabuela
-- Italian: Bisnonno / Bisnonna
-- Portuguese: Bisavô / Bisavó
-- All from Latin "bis" (twice) — shared Romance language root
-- ============================================================

UPDATE cultural_vocab_library
SET definition = 'Great-grandfather / Great-grandmother. Spanish uses the prefix "bis-" to mark one generation above grandparent, equivalent to the English "Great-." Cross-language note: the "bis-" prefix is shared across all three major Romance languages — Spanish: Bisabuelo/Bisabuela, Italian: Bisnonno/Bisnonna, Portuguese: Bisavô/Bisavó. All three trace to the Latin "bis" meaning "twice" — literally, twice-grandfather. English uses "Great-" instead, which is a Germanic construction. This is one of the clearest illustrations of the shared Latin root of the Romance kinship vocabulary.',
    updated_at = NOW()
WHERE term = 'Bisabuelo / Bisabuela' AND language = 'Spanish';

UPDATE cultural_vocab_library
SET definition = 'Great-grandfather / Great-grandmother. The "bis-" prefix works the same way in Italian as in Spanish — both languages trace it to the Latin "bis" (twice). Cross-language note: the great-grandparent prefix cluster across Romance languages — Spanish: Bisabuelo/Bisabuela, Italian: Bisnonno/Bisnonna, Portuguese: Bisavô/Bisavó. All from Latin bis = twice. English uses "Great-" (Germanic root). Tamil uses "Kollu-" as its generational prefix: Kollu Thatha for great-grandfather. Great-grandparents in Italian family culture are often still a living presence in family stories kept alive through food, gestures, and the stories Nonna tells.',
    updated_at = NOW()
WHERE term = 'Bisnonno / Bisnonna' AND language = 'Italian';

UPDATE cultural_vocab_library
SET definition = 'Great-grandfather / Great-grandmother in Portuguese. The "bis-" prefix is shared with Spanish and Italian — all three languages trace it to the Latin "bis" (twice). Cross-language note: great-grandparent prefix across Romance languages — Spanish: Bisabuelo/Bisabuela, Italian: Bisnonno/Bisnonna, Portuguese: Bisavô/Bisavó. English uses "Great-" (Germanic). Tamil uses "Kollu-": Kollu Thatha, Kollu Paati. Bisavô came from the Azores and settled in São Paulo. That is the whole history in one sentence.',
    updated_at = NOW()
WHERE term = 'Bisavô / Bisavó' AND language = 'Portuguese';

-- Also update Tamil Kollu Thatha to reference the Romance cluster
UPDATE cultural_vocab_library
SET definition = 'Great-grandfather / Great-grandmother in Tamil. Tamil has a complete generational vocabulary extending multiple generations: Kollu Thatha for great-grandfather, Poottan / Pootti for great-great-grandparent. Cross-language note: all major languages in this library have a great-grandparent construction. Romance languages (Spanish, Italian, Portuguese) all use the Latin prefix "bis-" (twice). English uses "Great-" (Germanic). Tamil''s "Kollu-" is the Dravidian equivalent — a prefix system that extends the generational vocabulary in the same logical direction, just from a completely independent linguistic root.',
    updated_at = NOW()
WHERE term = 'Kollu Thatha / Kollu Paati' AND language = 'Tamil';


-- ============================================================
-- CLUSTER I: EUROPEAN UNCLE/AUNT
-- Spanish: Tío / Tía
-- Italian: Zio / Zia
-- Portuguese: Tio / Tia
-- All from Latin — Z vs T variant from the same root
-- ============================================================

UPDATE cultural_vocab_library
SET definition = 'Uncle / Aunt. Spanish does not distinguish whether a Tío is a paternal or maternal uncle, or whether they are a blood relative or an in-law. Cross-language note: the European uncle/aunt cluster shares a Latin root — Spanish: Tío/Tía, Italian: Zio/Zia, Portuguese: Tio/Tia. The Italian Z and Spanish/Portuguese T are the same consonant shift from the Latin "avunculus" (uncle) and "amita" (aunt). In Dominican Republic, Puerto Rico, and parts of Cuba, Tío and Tía are also used informally as terms of warmth for close family friends and trusted adults who are not blood relatives.',
    updated_at = NOW()
WHERE term = 'Tío / Tía' AND language = 'Spanish';

UPDATE cultural_vocab_library
SET definition = 'Uncle / Aunt. Italian Zio and Zia cover all aunts and uncles regardless of whether they are paternal or maternal, blood relatives or in-laws. Cross-language note: the European uncle/aunt cluster shares a Latin root — Spanish: Tío/Tía, Italian: Zio/Zia, Portuguese: Tio/Tia. The Z in Italian and T in Spanish/Portuguese are the same consonant from different regional evolutions of Latin. In modern Italian, especially among younger generations, Zio (and its clipped form Zi'') is used informally among close friends. Like Spanish Tío and Portuguese Tio, it travels beyond blood relatives in informal use.',
    updated_at = NOW()
WHERE term = 'Zio / Zia' AND language = 'Italian';

UPDATE cultural_vocab_library
SET definition = 'Uncle / Aunt in Portuguese — shared Latin root with Spanish Tío/Tía and Italian Zio/Zia. Cross-language note: Spanish: Tío/Tía, Italian: Zio/Zia, Portuguese: Tio/Tia — all three pairs trace to the same Latin origin, with only a consonant shift distinguishing them. Like Spanish Tío and Italian Zio, Portuguese Tio/Tia are used beyond blood relatives: in Brazil, children call their parents'' close friends Tio and Tia as a mark of respect. In schools, children call teachers Tia until secondary level. Every adult my parents trusted was Tio or Tia to me.',
    updated_at = NOW()
WHERE term = 'Tio / Tia' AND language = 'Portuguese';


-- ============================================================
-- CLUSTER J: GODPARENT
-- Spanish: Padrino / Madrina
-- Portuguese: Padrinho / Madrinha
-- Both from Latin pater (father) / mater (mother)
-- Culturally parallel in both traditions
-- ============================================================

UPDATE cultural_vocab_library
SET definition = 'Godfather / Godmother. A sacred kinship role in Hispanic culture — not merely ceremonial but a real second-parent relationship created at baptism. Cross-language note: the godparent terms across Romance languages all trace to Latin — Spanish: Padrino/Madrina, Portuguese: Padrinho/Madrinha. Both derive from "pater" (father) and "mater" (mother) — literally, "father-figure" and "mother-figure." The cultural weight is nearly identical across Spanish and Portuguese Catholic communities: the compadre/comadre bond created between godparent and biological parent is as significant as the godparent-child relationship itself.',
    updated_at = NOW()
WHERE term = 'Padrino / Madrina' AND language = 'Spanish';

UPDATE cultural_vocab_library
SET definition = 'Godfather / Godmother in Portuguese — the same deeply significant role as the Spanish Padrino/Madrina. Cross-language note: Spanish Padrino/Madrina and Portuguese Padrinho/Madrinha are direct cognates from the Latin pater (father) and mater (mother). The cultural role is parallel in both communities — a lifelong bond created at baptism that makes the godparent an active second parent, not a ceremonial title. In Brazilian Catholic culture, the compadre/comadre bond between godparent and biological parent mirrors the Spanish Compadre/Comadre system precisely.',
    updated_at = NOW()
WHERE term = 'Padrinho / Madrinha' AND language = 'Portuguese';


-- ============================================================
-- CLUSTER K: HUSBAND''S SISTER / WIFE''S SISTER
-- Hindi: Nanad (husband''s sister)
-- Marathi: Nanand (husband''s sister)
-- Tamil: (covered under the kinship system entries)
-- ============================================================

UPDATE cultural_vocab_library
SET definition = 'Husband''s sister — a sister-in-law through marriage. The relationship between a wife and her Nanad is one of the most storied bonds in South Asian family life. Cross-language note: the husband''s sister has a distinct term across South Asian languages — Marathi: Nanand (note the slight spelling difference), both from the same Sanskrit root. In Bengali, Nanda refers to the husband''s sister as well. In Tamil, the husband''s sister relationship is addressed differently within the overall kinship system.',
    updated_at = NOW()
WHERE term = 'Nanad' AND language = 'Hindi';

UPDATE cultural_vocab_library
SET definition = 'Husband''s sister in Marathi — sister-in-law. The relationship between a wife and her nanand is one of the most nuanced in Marathi family life. Cross-language note: the husband''s sister cluster — Hindi: Nanad, Marathi: Nanand (shared Sanskrit root, slight spelling variant). In Bengali, the husband''s sister is addressed with the title Nanda. These terms all trace to the Sanskrit concept of the husband''s female family members, and the slightly different spellings across Marathi and Hindi reflect regional phonetic drift from a shared origin.',
    updated_at = NOW()
WHERE term = 'Nanand' AND language = 'Marathi';


-- ============================================================
-- CLUSTER L: ENGLISH UNCLE/AUNT — cross-reference
-- Updated to include full South Asian equivalent list
-- ============================================================

UPDATE cultural_vocab_library
SET definition = 'A parent''s brother, or the husband of a parent''s sibling. English uses one word where South Asian languages use six or more. Cross-language note: the full South Asian equivalent cluster for "uncle" — Hindi: Chacha (father''s younger brother), Tau (father''s elder brother), Mama (mother''s brother), Fufa (father''s sister''s husband), Mausa (mother''s sister''s husband). Tamil: Chittappa (father''s younger brother), Periappa (father''s elder brother), Maama (mother''s brother). Bengali: Kaka (father''s brother), Mama (mother''s brother). The collapse of all these into the single English word "Uncle" is one of the most cited examples in diaspora communities of what gets lost in translation.',
    updated_at = NOW()
WHERE term = 'Uncle' AND language = 'English';

UPDATE cultural_vocab_library
SET definition = 'A parent''s sister, or the wife of a parent''s sibling. As with Uncle, the English term collapses distinctions that are structurally preserved in most other language families. Cross-language note: the full South Asian equivalent cluster for "aunt" — Hindi: Chachi (wife of father''s younger brother), Tai (wife of father''s elder brother), Bua (father''s sister), Mausi (mother''s sister), Mami (wife of mother''s brother). Gujarati: Foi (father''s sister), Kaki (wife of father''s brother), Masi (mother''s sister). Tamil: Athai (father''s sister), Periamma (mother''s elder sister), Chitti (mother''s younger sister). The single English word "Aunt" erases all of this.',
    updated_at = NOW()
WHERE term = 'Aunt' AND language = 'English';


-- ============================================================
-- SECTION 4: MINOR REFINEMENTS
-- ============================================================

-- Bhabhi: clarify "typically elder brother" in definition
UPDATE cultural_vocab_library
SET definition = 'Brother''s wife — in common usage, typically the elder brother''s wife. A significant relationship that comes with its own set of rituals, affections, and responsibilities. Cross-language note: the elder brother''s wife has a distinct term in every South Asian language — Bengali: Boudi, Tamil: Anni, Marathi: Vahini, Gujarati: Bhabhi (shared with Hindi). Bhabhi was the newest member of the household but quickly became one of its pillars.',
    updated_at = NOW()
WHERE term = 'Bhabhi' AND language = 'Hindi';

-- ============================================================
-- END OF CORRECTIONS AND CROSS-REFERENCE FILE
-- Summary:
-- 1 error corrected (Bhanji usage example)
-- 1 term flagged (Bengali Nandai — reviewed = FALSE)
-- 1 new term inserted (Punjabi Mama)
-- 36 UPDATE statements adding cross-language overlap notes
-- across 12 relationship clusters
-- ============================================================
