-- ============================================================
-- EternalCurrent.Online -- Vocab Library Seed Batch 3
-- Generated: 2026-04-04
--
-- Languages added:
-- Punjabi (10 terms)
-- Gujarati (11 terms)
-- Bengali (11 terms)
-- Tamil (12 terms)
-- Portuguese / Brazilian Portuguese (10 terms)
--
-- Running total after this batch:
-- Batch 1: 36 | Batch 2: 53 | Batch 3: 54 = 143 terms
-- ============================================================

INSERT INTO cultural_vocab_library
  (term, language, cultural_origin, definition, usage_example,
   contributor_id, reviewed, visible_to, network_id)
VALUES


  -- ============================================================
  -- PUNJABI
  -- Spoken across Punjab (India and Pakistan), and one of the
  -- largest diaspora languages in the UK, Canada, and California.
  -- Shares roots with Hindi but has its own distinct vocabulary,
  -- tonal system, and living culture of address terms.
  -- ============================================================

  (
    'Bebe',
    'Punjabi', 'India',
    'Mother in Punjabi — one of the most distinctly Punjabi terms for the maternal figure, used widely across Sikh and Hindu Punjabi households. Where Hindi uses Maa or Amma, Punjabi families often use Bebe with a warmth that carries the entire weight of the Punjabi household matriarch. The term is also used respectfully for any older woman in the community.',
    'Bebe was the one who woke up before everyone and went to sleep after everyone. The house ran on her.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Bapu',
    'Punjabi', 'India',
    'Father in Punjabi — the everyday informal term for father used across Punjabi families. Where Hindi uses Baba or Papa, Punjabi uses Bapu, a term that carries both affection and the weight of patriarchal authority in the traditional Punjabi household. Papaji is the more formal, respectful variant used when addressing elders or speaking formally.',
    'Bapu did not say much, but when he spoke at the table the table went quiet.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Dada / Babaji',
    'Punjabi', 'India',
    'Paternal grandfather in Punjabi — father''s father. Dada is shared with Hindi but Punjabi families also use Babaji as an honorific form, particularly in Sikh households where the suffix -ji adds reverence. The paternal grandfather in Punjabi culture holds the senior-most position in the family structure and is the keeper of the family''s ancestral village identity (pind).',
    'Every story Babaji told began the same way: "In our village, back when things were different." They never got old.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Dadi / Biji',
    'Punjabi', 'India',
    'Paternal grandmother in Punjabi — father''s mother. Biji is the distinctly Punjabi term, carrying more warmth and specificity than the shared Dadi. In many Punjabi households, Biji is the operational head of the kitchen and the keeper of the family''s food culture — the person whose recipes are never fully written down because everyone assumed they would always be there to teach them.',
    'Biji''s hands knew the dough without measuring anything. That knowledge lived in her hands, not in a book.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Nana / Nani',
    'Punjabi', 'India',
    'Maternal grandfather / maternal grandmother in Punjabi — shared terms with Hindi. The maternal grandparent household (Nanihal) carries a particular quality in Punjabi culture — looser, more indulgent, the place where grandchildren go to be spoiled. The contrast between Nanihal (maternal home) and Dadihal (paternal home) is a recognized cultural distinction in Punjabi family life.',
    'Nanihal was where the rules relaxed. Nani said yes to things Dadi never would.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Taya / Tayaji',
    'Punjabi', 'India',
    'Father''s elder brother in Punjabi — equivalent to the Hindi Tau. Taya is the senior paternal uncle — the brother of your father who is older than your father. In traditional Punjabi joint family structure, the Taya held authority second only to the grandfather. Tayaji adds the respectful -ji suffix.',
    'You did not question Tayaji''s decision at the family meeting. That was not how it worked.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Chacha / Chachi',
    'Punjabi', 'India',
    'Father''s younger brother / his wife in Punjabi — shared with Hindi. Chacha is the paternal uncle who is younger than your father — a figure of warmth and often of fun, contrasted with the more authoritative Taya. Chachi is his wife. In Punjabi diaspora families, Chacha and Chachi often live in the same household or nearby, making these relationships daily presences rather than occasional visits.',
    'Chacha taught me to drive and said nothing to Bapu about the fence. That is what Chacha is for.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Maasi / Maasad',
    'Punjabi', 'India',
    'Mother''s sister / her husband in Punjabi — the maternal aunt and her husband. Maasi is one of the closest bonds in Punjabi family life — she knew your mother before she was your mother, which gives her a unique authority on who your mother actually is. Maasad is her husband, addressed with familial warmth.',
    'Maasi and my mother were inseparable growing up. When they were together you could see who they had been before any of us existed.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Veer / Veera',
    'Punjabi', 'India',
    'Brother in Punjabi — one of the most emotionally charged kinship terms in the language. Veer means both brother and brave/heroic, and the word''s double meaning is not accidental — the Punjabi brother is a protector by definition. Veera is the affectionate vocative form, the word a sister calls her brother. The brother-sister bond celebrated at Rakhri (Raksha Bandhan) is the relationship this word lives in.',
    'She called him Veera and he straightened up every time. That word always landed.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Bhua / Phuph',
    'Punjabi', 'India',
    'Father''s sister in Punjabi — the paternal aunt. Bhua in Punjabi, Bua in Hindi — the same deeply cherished relationship of the woman who left the household at marriage but never left the family. In Punjabi culture, Bhua has a particularly recognized status: she is the one who returns for every major ceremony and whose blessing carries weight. Also pronounced Phuph or Phuphi in some Punjabi households.',
    'Bhua came back for every wedding, every birth, every time the family needed someone who remembered where they came from.',
    NULL, TRUE, 'all', NULL
  ),


  -- ============================================================
  -- GUJARATI
  -- Spoken across Gujarat, India, and one of the most globally
  -- dispersed South Asian diaspora communities — East Africa,
  -- UK, North America. Large presence in Silicon Valley.
  -- Notable: all cousins are addressed as Bhai (brother) or
  -- Ben (sister) — there is no separate Gujarati word for cousin.
  -- ============================================================

  (
    'Ba',
    'Gujarati', 'India',
    'Paternal grandmother in Gujarati — also used as a term of address for the mother in some Gujarati families and communities. Ba is one of the most iconic Gujarati kinship terms, immediately recognizable. In Gujarati diaspora households in East Africa, the UK, and North America, Ba often refers specifically to the grandmother, the matriarch of the household who holds the family''s culinary and ritual knowledge.',
    'Ba''s voice in the kitchen in the morning was the sound that meant everything was going to be fine.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Dada / Bapuji',
    'Gujarati', 'India',
    'Paternal grandfather in Gujarati. Dada is the standard term; Bapuji is the more reverential form, carrying the weight of ancestral authority. In Gujarati culture, the paternal grandfather is the senior figure of the parivar (family unit) and the person who carries the family''s village and caste identity. Gujarati diaspora families in East Africa often preserved these terms through three and four generations.',
    'Dada knew everyone in the village by their full family name and their father''s name and their father''s father''s name.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Kaka / Kaki',
    'Gujarati', 'India',
    'Father''s brother / his wife in Gujarati — shared with Hindi and Marathi but with Gujarati-specific usage patterns. In Gujarati culture, all of the father''s brothers — older and younger — may be called Kaka, unlike Hindi which distinguishes Tau (elder) from Chacha (younger). Kaki is his wife. The name of the family member precedes the title: "Rajesh Kaka" not "Kaka Rajesh."',
    'Rajesh Kaka lived two streets away. In practice that meant he was at our house more than he was at his own.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Foi / Fua',
    'Gujarati', 'India',
    'Father''s sister / her husband in Gujarati — the Gujarati equivalent of the Hindi Bua. Foi is a distinctly Gujarati term with its own warmth and cultural weight — also spelled Foi, Fui, or Phoi in different communities. Fua is her husband. Foi''s children are addressed as Bhai (brother) or Ben (sister) — because in Gujarati there is no word for cousin. Everyone is a sibling.',
    'Foi traveled from Nairobi for the wedding. The distance was not a question anyone asked.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Masi / Masa',
    'Gujarati', 'India',
    'Mother''s sister / her husband in Gujarati — shared with Hindi Mausi/Mausa. Masi is the maternal aunt, the woman who knew your mother before she was your mother. In Gujarati communities, Masi and Maa are sometimes used interchangeably for very close maternal aunts, which tells you something about how the relationship is held. Masa is her husband.',
    'Masi was the person Maa called first. That is the only piece of information you need about their relationship.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Mama / Mami',
    'Gujarati', 'India',
    'Mother''s brother / his wife in Gujarati — the maternal uncle and his wife. Mama is shared across Gujarati, Hindi, Marathi, and Tamil. In Gujarati culture, Mama is a figure of particular warmth — the man who is your mother''s protector and therefore, by extension, yours. Mami is his wife. The maternal uncle''s household is often a second home.',
    'Mama''s house was where we went when things were difficult at home. Nobody had to explain. He already knew.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Ben',
    'Gujarati', 'India',
    'Sister in Gujarati — and also the term used for all female cousins. In Gujarati kinship culture there is no separate word for cousin: your father''s brother''s daughter is your Ben, your mother''s sister''s daughter is your Ben, your father''s sister''s daughter is your Ben. Everyone is either Bhai (brother) or Ben (sister). This is not a simplification — it reflects a genuine cultural value of treating extended family with sibling-level closeness.',
    'She introduced her cousin as "my Ben" and that was all anyone needed to know about how they were going to treat each other.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Bhai',
    'Gujarati', 'India',
    'Brother in Gujarati — and also the term for all male cousins. Like Ben for sisters, Bhai in Gujarati absorbs what English would call cousins into the sibling category. The name of the person precedes the title: "Haresh Bhai" not "Bhai Haresh." Bhai is also used as a general respectful address for any older male in the community, a usage pattern that extends across South Asian languages.',
    'He was Jayesh Bhai to the whole street. The family title traveled with him everywhere.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Vahu',
    'Gujarati', 'India',
    'Daughter-in-law in Gujarati — the woman who marries into the family. Vahu carries significant weight in Gujarati household culture: she is the newest member, the one who learns the household''s rhythms and recipes and rituals. Her integration into the family is a process, not a moment, and her relationship with the Ba (paternal grandmother) and the Sasu (mother-in-law) is one of the most culturally observed bonds in Gujarati family life.',
    'She became Vahu and inherited everything that word contains — the warmth, the expectation, and twenty years of recipes she was required to learn.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Jamai / Jijaji',
    'Gujarati', 'India',
    'Son-in-law / sister''s husband in Gujarati. Jamai is the man who marries your daughter; Jijaji is the man who marries your sister (elder sister''s husband specifically). In Gujarati culture, the son-in-law holds a particularly honored position — he is welcomed into the family with ceremony and is often treated as a privileged guest even after many years. The Gujarati saying "damad devo" (son-in-law is god) reflects this cultural attitude.',
    'Mahesh Jijaji arrived and suddenly the whole household shifted into hospitality mode. That is just what he was to this family.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Sasra / Sasu',
    'Gujarati', 'India',
    'Father-in-law / mother-in-law in Gujarati. Sasra is the wife''s father or the husband''s father; Sasu is the wife''s mother or the husband''s mother. In Gujarati family life, the mother-in-law (Sasu) is one of the most significant figures in a household — her relationship with the Vahu (daughter-in-law) shapes the emotional climate of the extended family.',
    'Sasu never asked directly. She observed, she assessed, and then one morning the recipe appeared on the counter written on a small piece of paper.',
    NULL, TRUE, 'all', NULL
  ),


  -- ============================================================
  -- BENGALI / BANGLA
  -- Spoken in West Bengal (India), Bangladesh, and diaspora
  -- communities globally. Second largest South Asian language.
  -- Notable: Hindu and Muslim Bengalis use some different terms.
  -- Bengali distinguishes paternal and maternal grandparents with
  -- entirely different vocabulary.
  -- ============================================================

  (
    'Thakurda / Thakuma',
    'Bengali', 'India',
    'Paternal grandfather / paternal grandmother in Bengali (Hindu usage). These are distinctly Bengali terms with no equivalent in Hindi — Thakurda for father''s father, Thakuma for father''s mother. The "Thakur" root carries a sense of deity and elevated status, reflecting the reverence given to the paternal grandparents in Bengali Hindu households. Muslim Bengalis often use Dadu and Dadi instead.',
    'Thakurda sat in the same chair every evening. We arranged ourselves around him like a family portrait that had been drawn that way for decades.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Dadu / Dida',
    'Bengali', 'India',
    'Maternal grandfather / maternal grandmother in Bengali — mother''s father and mother''s mother. Dadu and Dida are among the most beloved terms in Bengali family vocabulary, associated with the maternal grandparent household (Didibari) which carries a particular warmth and softness in Bengali culture. In some families, Dadu is also used for the paternal grandfather — the specific term depends on family and regional tradition.',
    'Dida''s kitchen was the original version of every dish the family makes. Everything else is an approximation.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Kaka / Kakima',
    'Bengali', 'India',
    'Father''s brother / his wife in Bengali. Kaka is the paternal uncle in Bengali, shared with Hindi and Gujarati but distinct in the -ima suffix for the wife. Kakima (literally "uncle-mother") carries a warmth specific to Bengali — the -ma suffix signals that this woman is a mother-figure within the household, not merely a relative by marriage.',
    'Kakima''s voice sounded enough like my mother''s that I sometimes forgot who I was talking to on the phone.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Pishi / Pisimaa',
    'Bengali', 'India',
    'Father''s sister in Bengali — the paternal aunt. Pishi is a uniquely Bengali term for the relationship that Hindi calls Bua and Gujarati calls Foi. Pisimaa is the respectful form. The relationship between a father''s sister and her brother''s children is one of the most emotionally charged in Bengali family life — she left the household at marriage but the bond, in Bengali culture, never fully released.',
    'Pishi came back for every milestone in our lives, from a different city each time. The distance never changed anything.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Mama / Mami',
    'Bengali', 'India',
    'Mother''s brother / his wife in Bengali — shared term across multiple South Asian languages. In Bengali, Mama is among the most affectionate of the extended family terms. The maternal uncle is often a figure of fun and indulgence, contrasted with the more formal paternal uncles. Mami is his wife. The Bengali diminutive Mamabaabu adds even more warmth.',
    'Mama brought sweets every single time he visited. Not sometimes. Every time. That was the rule he set for himself.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Mashi / Mashima',
    'Bengali', 'India',
    'Mother''s sister in Bengali — the maternal aunt. Mashi is one of the most widely used extended family terms in Bengali, and like Kaka/Kakima carries the -ma suffix in its respectful form, signaling maternal quality. In everyday Bengali life, Mashi and Kaku (paternal uncle) are also used as polite forms of address for older adults who are not related — the terms travel beyond blood.',
    'Everyone on the street was Mashi to someone. The word created a neighborhood out of people who might otherwise have just been neighbors.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Dada',
    'Bengali', 'India',
    'Elder brother in Bengali — and a term of respect for any older male. This is where Bengali diverges sharply from Hindi: in Hindi, Dada means paternal grandfather; in Bengali, Dada means elder brother. The same word carries completely different meanings across two major South Asian languages — a perfect illustration of why ECO holds terms in their cultural context rather than translating them into English.',
    'He was Dada to us and Thakurda to his grandchildren. The same man, two completely different words, both entirely accurate.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Didi',
    'Bengali', 'India',
    'Elder sister in Bengali — shared with Hindi. Didi is the respectful address for an older sister and, by extension, for any older woman in the community who has earned that closeness. In Bengal, Didi has also become a political honorific, but in family life it remains simply: the elder sister, the one who was there before you.',
    'You called her Didi and that was the whole relationship in one syllable.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Boudi',
    'Bengali', 'India',
    'Elder brother''s wife in Bengali — the sister-in-law through an elder brother. Boudi is a distinctly Bengali term with no direct equivalent in Hindi''s Bhabhi system in terms of its cultural weight. The arrival of a new Boudi into a Bengali household is a significant social event — she is the newest woman in the family''s female hierarchy, and her relationship with her husband''s sisters (Nanand/Didi) defines much of the household''s emotional climate.',
    'Boudi arrived and the household reconfigured itself around her presence. That is what a new Boudi does.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Mesho / Mesomoshai',
    'Bengali', 'India',
    'Mother''s sister''s husband in Bengali — the husband of the Mashi (maternal aunt). Mesho is the everyday form; Mesomoshai is the formal, respectful address. This is one of the more distinctly Bengali terms — the relationship that Hindi simply calls Mausa is given its own warm, specific form in Bengali. Mesho is often the quiet presence at the center of the Mashi''s household.',
    'Mesho never said much at family gatherings. But he noticed everything, and what he said when he did speak was always worth hearing.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Nandai',
    'Bengali', 'India',
    'Sister''s husband in Bengali — brother-in-law through a sister. Distinctly Bengali term for the man who marries your sister. In Bengali social structure, the Nandai occupies a particular position — formally welcomed into the family, often treated with great warmth by the wife''s family, and addressed with the full respect due a family elder if he is older.',
    'Nandai and my brother-in-law were the same person in English. In Bengali the word made it clear exactly which sister''s husband he was.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Jamai',
    'Bengali', 'India',
    'Son-in-law in Bengali — shared with Gujarati. The Jamai occupies a culturally celebrated position in Bengali family life, particularly in the tradition of Jamai Shashti — a festival specifically dedicated to honoring the son-in-law with food, gifts, and ceremony. The Bengalis have a saying: "Jamai ar jami" (son-in-law and land) — both are things you never stop tending.',
    'Jamai Shashti existed entirely because of him. One day a year, the whole household cooked what he wanted.',
    NULL, TRUE, 'all', NULL
  ),


  -- ============================================================
  -- TAMIL
  -- A Dravidian language — structurally distinct from all
  -- Indo-Aryan South Asian languages. One of the world''s oldest
  -- living languages. Large diaspora in UK, Canada, Singapore,
  -- Sri Lanka, and California. Tamil kinship vocabulary is
  -- notable for encoding seniority directly into the term:
  -- elder and younger siblings have completely different words.
  -- ============================================================

  (
    'Thatha / Paati',
    'Tamil', 'India',
    'Grandfather / Grandmother in Tamil — used for grandparents on both sides of the family in everyday speech, though formal Tamil distinguishes paternal and maternal variants. Thatha and Paati are among the first words Tamil children learn and among the last words adults forget. The affectionate suffix -vvu or reduplication (Thattha, Paatti) adds warmth in direct address.',
    'Paati''s stories were in Tamil even when everything else in the house had shifted to English. Some things she would not translate.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Appa / Amma',
    'Tamil', 'India',
    'Father / Mother in Tamil. Appa and Amma are the most fundamental kinship terms in Tamil and among the most recognizable Tamil words globally. They are part of the Dravidian root vocabulary — entirely different from the Sanskrit-derived Hindi Papa/Maa — and represent the linguistic independence of Tamil as a language family. In Tamil diaspora communities, Appa and Amma are often retained even by third and fourth generation speakers who have lost most other Tamil.',
    'She spoke Tamil only when she spoke to her parents. Appa and Amma were the words that remained.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Anna / Akka',
    'Tamil', 'India',
    'Elder brother / Elder sister in Tamil. Unlike English, which uses the same words for older and younger siblings, Tamil encodes seniority directly into the term — you cannot say "brother" in Tamil without also specifying whether that brother is older or younger than you. Anna for elder brother, Thambi for younger brother. Akka for elder sister, Thangachi for younger sister. This linguistic precision mirrors the social structure: elder siblings carry responsibility and respect that younger ones do not.',
    'She called him Anna and that one word established everything — his age, his authority, her position relative to his.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Thambi / Thangachi',
    'Tamil', 'India',
    'Younger brother / younger sister in Tamil. The counterparts to Anna and Akka. In Tamil kinship culture, being someone''s Thambi means you owe them deference; being someone''s Anna means you owe them protection. The seniority system is not ceremonial — it is structural. Tamil families navigate daily life through these encoded relationships in a way that the flat English "brother/sister" does not capture.',
    'He was Thambi to everyone older than him and Anna to everyone younger. His position in the family was a web, not a line.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Periappa / Chittappa',
    'Tamil', 'India',
    'Father''s elder brother / Father''s younger brother in Tamil. Tamil distinguishes not just paternal from maternal uncles but seniority within the paternal uncle category. Periappa is literally "big father" — the elder brother of your father, commanding a level of respect similar to a second father. Chittappa is "small/younger father" — your father''s younger brother, typically warmer and more informal. The naming convention tells you the entire relationship structure.',
    'Periappa was addressed like a second father. Chittappa was the one who taught you things your father was too serious to teach.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Periamma / Chitti',
    'Tamil', 'India',
    'Mother''s elder sister / Mother''s younger sister in Tamil. Periamma is "big mother" — the elder sister of your mother, who commands near-maternal respect. Chitti is the younger sister of your mother — more informal, often a close confidante and the person who spoils you with the things your mother won''t allow. Tamil''s kinship system encodes seniority so precisely that the word itself tells you how to behave.',
    'Periamma corrected us like our mother would. Chitti winked at us after Periamma left the room.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Athai',
    'Tamil', 'India',
    'Father''s sister in Tamil — the paternal aunt. Athai holds a particularly significant position in Tamil kinship structure: in traditional Tamil society, a cross-cousin marriage (marrying your Athai''s son or daughter) was not only permitted but preferred. This means your Athai was potentially also your future mother-in-law. The cultural complexity encoded in this one word is extraordinary — and it is one of the features that makes Tamil kinship vocabulary so academically rich.',
    'Athai''s son was also called Attan — the cross-cousin who was also a potential spouse in the old system. Tamil kinship holds histories English cannot name.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Maama / Mami',
    'Tamil', 'India',
    'Mother''s brother / his wife in Tamil. Maama is shared across Tamil, Hindi, Gujarati, Bengali, and Marathi — a pan-South Asian term for the maternal uncle. In Tamil, like in the Athai system, the Maama''s children are called Attan (male cross-cousin) and Athangai (female cross-cousin) — potential spouses in traditional Tamil kinship practice. Mami is his wife.',
    'Maama arrived with sweets and news from the maternal side of the family. He was the bridge between two household worlds.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Anni',
    'Tamil', 'India',
    'Elder brother''s wife in Tamil — sister-in-law through an elder brother. The arrival of Anni into the household is a significant moment in Tamil family life. She is the woman who married your Anna and now occupies the same household hierarchy layer as him. Her relationship with the younger siblings — the Thambi and Thangachi — defines much of the household''s daily dynamic.',
    'Anni was the one who remembered everyone''s birthday after Anna forgot his own.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Mamanar / Maamiyaar',
    'Tamil', 'India',
    'Father-in-law / Mother-in-law in Tamil. Mamanar is the father-in-law — notably, the same root as Maama (maternal uncle) because in traditional Tamil society these roles overlapped. Maamiyaar is the mother-in-law. The Tamil in-law vocabulary is built on the kinship structure, not just on the marriage event, which is why the words feel related to other family terms rather than being constructed separately.',
    'Maamiyaar and Amma used the same expressions for the same things. I had married into the same language.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Kollu Thatha / Kollu Paati',
    'Tamil', 'India',
    'Great-grandfather / Great-grandmother in Tamil. Tamil has a complete generational vocabulary extending multiple generations: Kollu Thatha for great-grandfather, Poottan / Pootti for great-great-grandparent. The generational depth of Tamil kinship vocabulary reflects a culture that tracked lineage carefully across many generations — not just two or three.',
    'We have a photograph of Kollu Paati. Nobody alive met her. But everyone knows her name.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Attan / Athangai',
    'Tamil', 'India',
    'Cross-cousin in Tamil — specifically, the son or daughter of your Athai (father''s sister) or your Maama (mother''s brother). In traditional Tamil kinship, the Attan (male) and Athangai (female) are the preferred marriage partners — the cross-cousin marriage system. This means that the same person who is your cousin is also your potential spouse, and Tamil has a specific word for this relationship that captures both its everyday warmth and its structural significance.',
    'In the old system, Attan was not just a cousin — he was the cousin, the one the family had in mind. That system has faded, but the word and the closeness it implies have not.',
    NULL, TRUE, 'all', NULL
  ),


  -- ============================================================
  -- PORTUGUESE / BRAZILIAN PORTUGUESE
  -- Spoken in Brazil (210M+), Portugal, Mozambique, Angola,
  -- Cape Verde, and diaspora communities globally.
  -- Brazilian Portuguese has distinct affectionate variants
  -- (Vovô/Vovó) alongside the formal (Avô/Avó).
  -- Like Spanish, the -inho/-inha diminutive system creates
  -- affectionate versions of almost every kinship term.
  -- ============================================================

  (
    'Avô / Avó',
    'Portuguese', NULL,
    'Grandfather / Grandmother in Portuguese — the formal terms. The accent distinguishes them: Avô (circumflex) for grandfather, Avó (acute) for grandmother. Like Spanish Abuelo/Abuela, Portuguese does not distinguish maternal from paternal grandparents in the base term. In everyday Brazilian speech, these formal terms are rarely used — the affectionate Vovô and Vovó almost always replace them.',
    'We called him Avô in formal situations and Vovô at the dinner table. The word changed but the man was the same.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Vovô / Vovó',
    'Portuguese', NULL,
    'Grandpa / Grandma in Brazilian Portuguese — the affectionate everyday forms of Avô/Avó. Vovô and Vovó are among the most warmly recognizable Brazilian Portuguese kinship terms. Some families shorten them further to Vô and Vó. In Portugal, you are more likely to hear Avozinho/Avozinha as the diminutive. The vovô and vovó terms signal the intimacy of Brazilian family culture, where formal distance from grandparents would itself be culturally unusual.',
    'Vovó asked about your love life at every family gathering, regardless of your age or previous answers.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Bisavô / Bisavó',
    'Portuguese', NULL,
    'Great-grandfather / Great-grandmother in Portuguese. The "bis-" prefix is shared with Spanish and Italian — all three languages trace it to the Latin "bis" (twice). Great-grandparent in Brazilian Portuguese culture is often still a living presence in family stories, kept alive through the churrasco recipes, the Portuguese songs, and the photographs that survive the generations.',
    'Bisavô came from the Azores and settled in São Paulo. That is the whole history in one sentence.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Tio / Tia',
    'Portuguese', NULL,
    'Uncle / Aunt in Portuguese — shared with Spanish. Like Spanish Tío/Tía, Portuguese Tio/Tia are used beyond blood relatives: in Brazil, children call their parents'' close friends Tio and Tia as a mark of respect and affection. In schools, children call teachers Tia until they reach secondary level. The term travels across the boundary of biological relationship and becomes a cultural form of address.',
    'Every adult my parents trusted was Tio or Tia to me. I did not understand until much later that some of them were not actually related to us.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Primo / Prima',
    'Portuguese', NULL,
    'Male cousin / Female cousin in Portuguese — shared with Spanish. Portuguese genders the cousin term and does not distinguish first from second cousins in everyday speech. In Brazilian culture, primos are a fundamental part of the extended family network — they are present at every churrasco, every celebration, every gathering where the extended family assembles.',
    'My prima and I grew up in different states. At every family gathering we picked up exactly where we left off.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Sobrinho / Sobrinha',
    'Portuguese', NULL,
    'Nephew / Niece in Portuguese. Sobrinho for nephew, Sobrinha for niece. Like the Spanish Sobrino/Sobrina, Portuguese does not distinguish whose child the niece or nephew is — one word for all nephews, one for all nieces. The role of aunt or uncle toward the sobrinhos in Brazilian culture is warm and participatory — not distant. Tio and Tia are expected to be genuinely present.',
    'She treated her sobrinhos like a second set of children. That was not unusual — in this family, it was expected.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Sogro / Sogra',
    'Portuguese', NULL,
    'Father-in-law / Mother-in-law in Portuguese. Unlike English which attaches "-in-law" to an existing parent term, Portuguese creates entirely separate vocabulary for in-law parents — as does Spanish and Italian. Notably, in Brazil, Sogro/Sogra are used even in unmarried relationships of significant duration, which tells you something about Brazilian social norms around partnership and family recognition.',
    'She referred to his mother as her Sogra from the first year. In Brazil, that is not presumptuous. That is just how it works.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Cunhado / Cunhada',
    'Portuguese', NULL,
    'Brother-in-law / Sister-in-law in Portuguese. From the Latin "cognatus" — related by birth — the same root as the Italian Cognato. Portuguese Cunhado covers both the spouse''s sibling and the sibling''s spouse. In Brazilian family culture, the Cunhado is a figure of both warmth and cultural humor — the subject of many jokes about over-involvement in family affairs.',
    'My Cunhado arrived at every family event with an opinion about everything. Nobody asked. That did not matter.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Padrinho / Madrinha',
    'Portuguese', NULL,
    'Godfather / Godmother in Portuguese — the same deeply significant role as the Spanish Padrino/Madrina. In Brazilian Catholic culture, the godparent relationship created at baptism is a lifelong bond — the padrinho and madrinha are expected to be actively present in the godchild''s life, not merely ceremonially so. The word Compadre/Comadre (co-parent) describes the bond this creates between the godparent and the child''s parents.',
    'My padrinho was at every birthday, every graduation, every crisis. That is what the role demands and he never questioned it.',
    NULL, TRUE, 'all', NULL
  ),

  (
    'Meu bem / Meu amor',
    'Portuguese', NULL,
    'My darling / My love — terms of endearment used within families across generations in Brazilian Portuguese. Unlike English where "my love" is primarily romantic, in Brazilian culture these terms flow freely between parents and children, grandparents and grandchildren, and between close family members of any age. A grandmother calls her grandchild "meu bem." A mother calls her grown son "meu amor." The terms carry no exclusive romantic claim.',
    'She called every person she loved "meu bem" — her grandchildren, her children, even the dog. In her house love was distributed without economy.',
    NULL, TRUE, 'all', NULL
  );

-- ============================================================
-- END OF VOCAB LIBRARY SEED BATCH 3
-- 54 terms across 5 languages:
-- Punjabi (10), Gujarati (11), Bengali (11), Tamil (12),
-- Portuguese/Brazilian Portuguese (10)
--
-- Cumulative library total:
-- Batch 1 (36) + Batch 2 (53) + Batch 3 (54) = 143 terms
-- Languages: Hindi, Urdu, Fijian Hindi, Marathi, Punjabi,
--   Gujarati, Bengali, Tamil, English, Spanish, Dominican Spanish,
--   Italian, Portuguese
-- ============================================================
