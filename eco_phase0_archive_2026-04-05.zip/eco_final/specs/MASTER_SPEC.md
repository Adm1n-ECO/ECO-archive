# EternalCurrent.Online (ECO) — Master Specification
# Session Archive: 2026-04-04 / 2026-04-05
# Author: Vikas Bakshi (STAR) + Claude
# ============================================================

## IDENTITY

- Platform: EternalCurrent.Online (ECO)
- Parent brand: CRUNOD / LookMeUp.Online
- Founder: Vikas Bakshi (UserID: STAR) — vikas@eternalcurrent.online
- Co-founder: Isaiah Bakshi (son, College of San Mateo student)
- Pilot network: lightning-001 — 104 members, Free_Forever tier, Bakshi-Datta-Singh family

---

## LOCKED BRAND DECISIONS (NEVER CHANGE)

### Colors
- Background void: #080D14
- Electric Blue (ETERNAL): #00AAFF
- Go Green (CURRENT): #00CC44
- Full White: #FFFFFF

### ECO Wordmark
- E = #00AAFF (Electric Blue)
- C = #00CC44 (Go Green)
- O = #FFFFFF (Full White)
- This sequence is permanent. Never alter.

### Typography
- Headings: Arial Black, weight 900
- Body: Arial / Helvetica, weight 400-500
- NO Google Fonts. NO serif fonts. Arial only across all surfaces.

### Globe Arc Colors
- India origin: amber #FFB347
- Fiji origin: teal #00CED1
- Pakistan origin: purple #9B59B6
- Adopted: electric blue #00AAFF
- Unknown/null: white rgba(255,255,255,0.4)

### Bidirectional Current (locked definition)
Energy flows INTO you from your network AND OUT from you into theirs — simultaneously, always.
Energy = "Only energy — Compounding, Communicating, Conjoining"
- Compounding = Eternal
- Communicating = Current
- Conjoining = network

### Core Ownership Statement
"You are not the product. You never will be."
Subscription justification deliberately excluded — moral commitment must not feel contingent on business model.

### No Forms Rule
Not a single HTML form tag anywhere on the platform. All input is conversational AI, single tap/toggle, live search, or file picker. Auth is the minimal exception (two sequential prompts, no form tag). Progressive save on every answer.

---

## TECH STACK

- Domain: Namecheap (registration only)
- Hosting: Vercel
- Framework: Next.js (future — not yet implemented)
- Database: Supabase (Postgres + RLS) — LIVE
- Interim layer: Google Apps Script (RETIRING — replaced this session)
- AI: Claude API — model claude-haiku-4-5-20251001, key stored as eco_claude_key
- Globe: Three.js r128, custom GLSL shaders
- Chord diagram: D3 v7
- Textures: Local /textures/ folder — NEVER CDN
  - earth_daymap.jpg (from Three.js planet examples)
  - earth_normalmap.jpg (from Three.js planet examples)
- Auth: Supabase Auth, magic link (no passwords)

### Supabase Project
- URL: https://bmipnqgofezjcllhmczg.supabase.co
- Project ID: bmipnqgofezjcllhmczg
- Region: East US (Ohio) us-east-2
- Publishable key: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJtaXBucWdvZmV6amNsbGhtY3pnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzUyNjIxMDksImV4cCI6MjA5MDgzODEwOX0._izGhqbWSzdF9HbafNjxLeCVtgVWojpSMIotXSJbH0k
- Auth Site URL: https://eternalcurrent.online
- Auth Redirect URLs: https://eternalcurrent.online, /globe-live.html, /login.html, localhost:8080
- Magic link email template: ECO-branded, dark theme, "Your link to the family network — EternalCurrent" subject

---

## DATABASE — COMPLETE SCHEMA (Phase 0)

### Tables (10)
1. networks — one row: lightning-001
2. users — 104 members (87 Living, 17 Passed, 0 Placeholder)
3. relationships — 448 directed edges
4. pets — 8 records
5. accomplishments — 1 starter record
6. cultural_vocab_library — 143 terms across 13 languages
7. banner_statements — 15 founding statements
8. banner_impressions — tracking schema
9. waitlist — schema only
10. journeys — 68 records (placeholder schema, full redesign pending)
11. location_coords — 25 geocoded locations (added file 11)

### Key Columns Added This Session
- users.birth_lat, birth_lon, current_lat, current_lon (file 11)
- users.languages_spoken TEXT[] (file 12)
- users.auth_id UUID (file 03 — bridge to Supabase Auth)
- journeys.lat, journeys.lon (file 11)

### Views
- users_public — email and auth_id structurally excluded
  Current columns: user_id, network_id, full_name, first_name, middle_name,
  last_name, nickname, platform_role, family_role, status, tier, gender,
  cultural_origin, birth_mm_yyyy, birth_location, current_location,
  household_id, parent_id, co_parent_id, partner_id, partner_type,
  social_links, photo_id, invite_status, visible_to, bio,
  birth_lat, birth_lon, current_lat, current_lon, languages_spoken,
  created_at, updated_at

### Triggers
- trg_sync_user_coordinates — auto-resolves lat/lon on birth/current location save
- trg_sync_journey_coordinates — auto-resolves lat/lon on journey location save

### Roles
- platform_role enum: SuperUser, NetworkOwner, Moderator, Keeper, Conductor, Scholar, Guest
- SuperUser = admin@eternalcurrent.online (system only, no network membership)
- NetworkOwner = Vikas (STAR) in lightning-001

### Tiers
- Free_Forever — all 104 lightning-001 members
- Conductor — $5.99/mo
- ConductorPro — $8.99/mo
- Student — $3/mo
- OrgAdmin — $14.99/mo
- Placeholder — not yet activated

---

## SQL FILES — RUN ORDER AND STATUS

| File | Description | Status |
|------|-------------|--------|
| 01_CREATE_TABLES.sql | All 10 tables + 16 indexes | ✅ Run |
| 02_INSERT_DATA_v2.sql | 104 users, 448 rels, pets, accomplishments, journeys | ✅ Run |
| 03_RLS_POLICIES.sql | Row-level security, users_public view, auth_id | ✅ Run |
| 04_SEED_BANNER.sql | 15 founding banner statements | ✅ Run |
| 05_SEED_VOCAB.sql | 36 vocab terms batch 1 | ✅ Run |
| 06_SEED_VOCAB_BATCH2.sql | 53 vocab terms batch 2 | ✅ Run |
| 07_SEED_VOCAB_BATCH3.sql | 55 vocab terms batch 3 | ✅ Run |
| 08_VOCAB_CORRECTIONS_AND_XREF.sql | Corrections + 36 cross-language updates | ✅ Run |
| 09_AUTH_SETUP.sql | STAR email + auth_id link (Step 1 done, Step 2 pending) | ⚠️ Step 1 only |
| 10_PLACEHOLDER_TO_LIVING.sql | 49 Placeholder → Living | 🔲 NOT RUN |
| 11_GEOCODE_LOCATIONS.sql | Coordinates, triggers, location_coords table | ✅ Run |
| 12_ADD_LANGUAGES.sql | languages_spoken column + view update + seed | ✅ Run |
| 13_LANGUAGE_UPDATES.sql | Patel→Gujarati, STAR→Spanish, Fiji/Singh→Fijian Hindi+Hindi | ✅ Run |

⚠️ FILE 10 STILL NEEDS TO BE RUN — 49 records still showing as Placeholder

### One-off SQL also run (not in files)
- users_public view refresh (after file 11 added coordinates)
- users_public view DROP + recreate (after languages column added)

---

## LIGHTNING-001 NETWORK DATA

### Network Stats
- 104 total members
- 87 Living (after file 10 runs — currently some still Placeholder)
- 17 Passed
- 448 relationships
- 25 geocoded locations
- 7 languages: English(41), Hindi(32), Fijian Hindi(10), Gujarati(9), Urdu(9), Spanish(1), Punjabi(1)

### Family Structure (LOCKED — never alter)
- Krishan + Leela Datta → 3 children: Nirupma (Neeru), Babloo, Anu
- Madan + Nirupma → Vikas, Amit† (AB-STAR, deceased), Pragati
- Narendra + Jaiwati Singh → 3 daughters: Reema, Karishma, Seema
- Ramesh Sewak = Jaiwati's brother (NOT her child)
- Isaiah: adopted by Vikas + Reema; birth father = Amit† (AB-STAR)
- Niti Vaid = Anu + Satish Vaid's daughter = Vikas's first cousin
- Birth dates stored as MM/YYYY only — NEVER the day

### Key Relationships
- Vikas STAR = NetworkOwner, lightning-001
- Reema RRB-STAR = Vikas's wife, Fiji origin (Suva)
- Isaiah IB-STAR = Adopted son, birth father = Amit†
- Niti Vaid NV-STAR = First cousin, Thousand Oaks CA
- Sahiba = Niti Vaid's daughter (upcoming wedding — highest-leverage acquisition event)

---

## VOCABULARY LIBRARY — 143 TERMS

### Languages Covered
1. Hindi (paternal, maternal, siblings, in-laws)
2. Urdu / Pakistani
3. Fijian Hindi (including Jij, Jijiya, Ladkan, Bhayia, Dada, Dadi)
4. Punjabi
5. Gujarati
6. Bengali
7. Tamil
8. Marathi
9. English (generational system, cousin terminology)
10. Spanish / Hispanic
11. Dominican Spanish
12. Italian (Northern)
13. Portuguese / Brazilian Portuguese

### Cross-Language Clusters Documented
- Mother's brother: Mama (Hindi/Gujarati/Bengali/Marathi/Punjabi), Maama (Tamil), Mamu (Urdu)
- Father's sister: Bua/Phupho/Foi/Pishi/Atya/Bhua/Athai
- Mother's sister: Mausi/Khalah/Masi/Mashi/Mavshi/Maasi/Periamma/Chitti
- Dada collision: GRANDFATHER in Hindi/Gujarati/Punjabi/Fijian Hindi vs ELDER BROTHER in Bengali/Marathi
- Tai collision: Father's elder brother's wife (Hindi) vs Elder sister (Marathi)
- European bis- prefix: Spanish/Italian/Portuguese all from Latin "bis" (twice)

### Known Issue
- Bengali Nandai: flagged reviewed=FALSE, pending native speaker confirmation

---

## GLOBE-LIVE.HTML — CURRENT STATE

### What works
- Three.js globe with earth_daymap.jpg + earth_normalmap.jpg textures
- Auto-rotate, drag-to-rotate, scroll-to-zoom, touch support
- Supabase data fetch (users_public + relationships)
- Stats bar: Members / Journeys / Countries / Languages
- Clustered dots (multiple people at same location → single sized dot)
- Migration arcs (birth→current, QuadraticBezierCurve3, height scales with distance)
- Location popup on dot click (lists all people at that location)
- Profile card (limited fields for anonymous: origin, birth, current, role, connection count)
- Directory slide-out panel (searchable, alphabetical, links to profile)
- Chord diagram panel (Branch view + Cultural Origin view, D3)
- AI claim flow (local matching: name/nickname, confirm, languages question, email)
- Passed member handling (perspective offer only, no claim prompt, no "Passed" label)
- ECO-branded magic link email template in Supabase Auth

### What's NOT built yet (TODOs in code)
- signInWithOtp() — magic link not yet wired to Supabase Auth
- Waitlist insert + notify vikas@eternalcurrent.online for new visitors
- Perspective switching (redraws network centered on selected user)
- Mobile responsive layout (bottom sheet pattern)

### Known issue
- File 10 (Placeholder→Living) not yet run — some records may still show as Placeholder
- users_public view must include all coordinate + language columns (was manually refreshed)

---

## PAGES STATUS

| Page | Status | Supabase Connected |
|------|--------|--------------------|
| globe-live.html | ✅ Built, live at eternalcurrent.online/globe-live.html | ✅ Yes |
| index.html | Exists (prior build) | 🔲 Not yet |
| confluence.html | Exists (prior build) | 🔲 Not yet |
| login.html | 🔲 Not built | N/A |
| landing page | 🔲 Not built | N/A |

---

## PENDING BUILD QUEUE (Priority Order)

### Immediate — next session
1. Run file 10 (Placeholder→Living) — 5 min SQL
2. Verify users_public view has all columns — quick check
3. Wire Sign In magic link in globe-live.html (signInWithOtp)
4. Add waitlist insert + vikas email notification to AI flow
5. Build login.html — ECO branded, magic link entry

### Short-term
6. Mobile-responsive globe-live.html (bottom sheet pattern)
7. Landing page — glass door overlay concept
   - Black/white stylized globe (lightweight, no NASA texture)
   - Frosted glass overlay on existing index.html
   - Scroll (desktop) / tap (mobile) to reveal
   - Simulated arc labels: "a grandmother's journey", "where two families met" etc.
   - Two lines + one button: "Every family crossed something to get here." / "Open yours →"
8. index.html Supabase connection (banner statements, waitlist)
9. confluence.html Supabase connection (vocab library, language filter)

### Medium-term (Phase 1 prep)
10. Perspective switching feature (redraws constellation from any user's POV)
11. Profile edit flow (member claims profile, adds data, adds family members)
12. Milestone Experience feature (wedding/graduation/birth/etc.)
    - milestones table design
    - milestone.html template (mobile-first)
    - /m/[slug] URL routing
    - QR code generation (client-side JS)
    - AI-conversation milestone creator (no forms)
    - Event feed (guests post messages during event)
13. Auth wiring complete (link auth_id to user records as members sign in)
14. Email notifications to vikas@eternalcurrent.online for new members/additions

### Phase 1 (paid tiers)
15. Subscription tier deployment (Conductor $5.99, ConductorPro $8.99, OrgAdmin $14.99)
16. Sanity CMS integration
17. SMTP setup (replace Supabase built-in email)

---

## MILESTONE EXPERIENCE FEATURE DESIGN

### What it is
ECO Milestone Experience — a reusable, network-owner-created shareable page for life milestones.

### Milestone Types
- Wedding / Union (two networks merging — arc colors converge)
- Birth / Baby shower / Gender reveal (new node appears)
- Graduation (one person's journey arc)
- Milestone birthday (18, 21, 30, 50, 75, 100)
- Retirement
- Memorial / Celebration of life (perspective-switch feature)
- Reunion (family, class, military)
- Immigration / Citizenship

### URL Structure
eternalcurrent.online/m/[slug]
Example: eternalcurrent.online/m/sahiba-wedding-2026

### Database Table Needed
milestones:
- milestone_id, network_id, type, title, slug (unique)
- honoree_user_ids (array — two for wedding, one for graduation etc.)
- date_mm_yyyy, location, cover_message
- vendor_opt_in BOOLEAN
- status (Active/Archived)
- created_by, created_at

### Creation Flow
AI conversation (no forms):
"Who is this milestone for? What are we celebrating? When and where?"
Builds the record from conversation. Mobile-first.

### Vendor Layer (Phase 2)
- Network owner opts in only
- Curated vendor placement (photographer, planner, cultural coordinator)
- Vendor pays ECO for placement
- Guest never sees unsolicited ad

---

## AFFILIATE / REVENUE MODEL

### Layer 1 — Subscriptions (Phase 1)
Conductor $5.99, ConductorPro $8.99, Student $3, OrgAdmin $14.99
No auto-renewal fees. Freeze-not-delete on lapse.

### Layer 2 — Milestone Event Commerce (Phase 2)
Network owner opts in. Curated vendor marketplace.
ECO takes placement fees. Members never see unsolicited ads.

### Layer 3 — Contextual Affiliates (Phase 2)
Babbel language learning — triggered by vocab library engagement
Appears: next to terms in languages member doesn't speak,
after profile languages are captured, never more than once per session.
Rules: opt-in only, one suggestion at a time, never in globe view,
dismissible permanently.

---

## AI CLAIM FLOW — COMPLETE LOGIC

```
LIVING member, nickname exists:
"Are you [Nickname]?"

LIVING member, no nickname:
"Are you the [FirstName] from [BirthCity]?"

Multiple matches:
"We found a few: [list]. Which one are you?"

Confirmed match:
"Welcome[, Nickname]. Quick question — what languages do you speak?"
→ Collect languages
→ "To save your story — what email should we send your link to?"
→ Send magic link via Supabase Auth signInWithOtp
→ "Your link is on its way to [email]. Your family is glad you're here."

PASSED member (someone viewing, not claiming):
"[Full Name] — born [birth_location][, birth_mm_yyyy].
Their story is part of this network.
Would you like to see this family the way [FirstName] would have seen it?"
NO "Passed" label. NO claim prompt. NO questions.

NOT in network:
"We don't have you in here yet — but that's easy to fix.
How are you connected to this family?"
→ Collect connection description
→ "What's your email? Vikas will add you shortly."
→ Insert waitlist record
→ Notify vikas@eternalcurrent.online
→ Immediately visible as pending member

SIGN IN mode:
"Welcome back. What email did you use to join EternalCurrent?"
→ signInWithOtp({email})
→ "Link sent to [email]. One click and you're in."
```

---

## MOBILE UX — DESIGN DECISIONS

### globe-live.html mobile layout
- Globe: full screen
- Stats: small pill at top
- Controls: bottom tab bar (icons, not text buttons)
- Dot tap: bottom sheet slides up with location name + people list
- Profile cards: full-screen bottom sheets
- Directory: full-screen bottom sheet from bottom tab
- Chord diagram: full-screen view from bottom tab
- AI claim: modal at 90% screen height
- Touch: 1 finger = rotate, 2 finger pinch = zoom, tap = select, swipe down = dismiss

### Landing page mobile
- Globe fills viewport
- Frosted glass overlay
- Tap (not scroll) to reveal page beneath
- "Open yours →" button triggers reveal

---

## LANDING PAGE — GLASS DOOR CONCEPT

### Concept
Frosted glass overlay on existing index.html.
Visitor sees existing page content blurred behind glass.
Globe floats on overlay layer — black/white stylized (not NASA texture).
Scroll down (desktop) or tap (mobile) dissolves overlay.
Globe does not persist after door opens.

### Globe style
- Dark background
- White continent outlines only (no fill)
- Single small PNG of continent outlines on transparent background
- Arc labels on hover: "a grandmother's journey", "where two families met",
  "the crossing that started everything", "where home still is"
- Simulated data only — no real member data on this page
- Loads under 100kb

### Text
Line 1: [Hero question — needs final wording]
Candidates:
- "Do you know the world that made you?"
- "Your family moved. Your language shifted. Your name traveled. Do you know the full story?"
- "Every family crossed something to get here. Do you know what yours crossed?"

Line 2: "Every family has a network. Most of it is invisible."

Button: "Open yours →" (triggers reveal)
Secondary: "Learn More" (links to existing index.html content)

---

## SESSION RULES (standing instructions for all sessions)

1. Update spec documents in place. Never zip unless explicitly asked.
2. Only changed files updated — minimize token usage.
3. All design decisions confirmed before any file output.
4. One workstream at a time — no jumping ahead.
5. HTML never touched until data layer is confirmed.
6. Birth dates: MM/YYYY only, never the day.
7. No forms anywhere — not a single HTML form tag.
8. ECO wordmark always: E=#00AAFF C=#00CC44 O=#FFFFFF.
9. Globe textures always local /textures/ — never CDN.
10. Never test with file:// URLs — always python -m http.server 8080.
